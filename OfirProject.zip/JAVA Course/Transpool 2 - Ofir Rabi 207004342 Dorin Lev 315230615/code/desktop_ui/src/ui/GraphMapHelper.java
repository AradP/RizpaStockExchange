package ui;

import com.fxgraph.graph.Graph;
import com.fxgraph.graph.Model;
import controllers.BLManegment;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import models.Stop;
import models.TripOfferWithStop;
import puk.team.course.tarnspool.graph.component.coordinate.CoordinateNode;
import puk.team.course.tarnspool.graph.component.coordinate.CoordinatesManager;
import puk.team.course.tarnspool.graph.component.details.StationDetailsDTO;
import puk.team.course.tarnspool.graph.component.road.ArrowedEdge;
import puk.team.course.tarnspool.graph.component.station.StationManager;
import puk.team.course.tarnspool.graph.component.station.StationNode;
import puk.team.course.tarnspool.graph.layout.MapGridLayout;
import java.util.ArrayList;
import java.util.List;

public abstract class GraphMapHelper {
    public static void initializeMap(Graph graph) {

        final Model model = graph.getModel();
        graph.beginUpdate();

        StationManager sm = createStations(model);
        CoordinatesManager cm = createCoordinates(model);
        createEdges(model, cm);

        graph.endUpdate();

        graph.layout(new MapGridLayout(cm, sm));
    }

    private static StationManager createStations(Model model) {
        StationManager sm = new StationManager(StationNode::new);

        BLManegment.getAllStops().forEach(stop -> {
            StationNode station = sm.getOrCreate(stop.getX(), stop.getY());
            station.setName(stop.getName());
            List<TripOfferWithStop> tripOfferWithStops = BLManegment.getCurrentTripOffersWithStop(stop.getName());
            station.setAmount(tripOfferWithStops.size());
            station.setDetailsSupplier(() -> {
                List<String> trips = new ArrayList<>();
                trips.add(tripOfferWithStops.toString());
                return new StationDetailsDTO(trips);
            });
            model.addCell(station);
        });

        return sm;
    }

    private static CoordinatesManager createCoordinates(Model model) {

        CoordinatesManager cm = new CoordinatesManager(CoordinateNode::new);

        for (int i = 0; i< BLManegment.getMapBoundries().getHeight(); i++) {
            for (int j = 0; j < BLManegment.getMapBoundries().getWidth(); j++) {
                model.addCell(cm.getOrCreate(i+1, j+1));
            }
        }

        return cm;
    }

    private static void createEdges(Model model, CoordinatesManager cm) {
        BLManegment.getAllPaths().forEach(path -> {
            Stop from = BLManegment.getStopByName(path.getFrom());
            Stop to = BLManegment.getStopByName(path.getTo());
            ArrowedEdge arrow = new ArrowedEdge(cm.getOrCreate(from.getX(),from.getY()),
                                                cm.getOrCreate(to.getX(),to.getY()),
                                                path.isOneWay());
            model.addEdge(arrow);
        });
//        Platform.runLater(() -> {
//            e13.getLine().getStyleClass().add("line1");
//            e13.getText().getStyleClass().add("edge-text");
//
//            e34.getLine().getStyleClass().add("line2");
//            e34.getText().getStyleClass().add("edge-text");
//
//            e23.getLine().getStyleClass().add("line3");
//            e23.getText().getStyleClass().add("edge-text");
//        });
    }
}
