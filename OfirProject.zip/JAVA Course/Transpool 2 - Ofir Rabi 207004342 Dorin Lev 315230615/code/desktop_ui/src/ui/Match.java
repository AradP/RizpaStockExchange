package ui;

import controllers.BLManegment;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import models.TripRequest;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Match extends Application implements Initializable {
    @FXML
    public TextField amountTxt;
    @FXML
    public ListView requestList;
    @FXML
    public ListView matchesList;
    @FXML
    public Button submitButton;
    private Main mainController;

    @Override
    public void start(Stage stage) throws Exception {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList offersItems = FXCollections.observableArrayList();
        offersItems.setAll(BLManegment.getUnmatchedRequests());
        requestList.setItems(offersItems);
    }

    public void setMainController(Main mainController) {
        this.mainController = mainController;
    }

    @FXML
    public void findMatch(ActionEvent event) {
        String selectedRequest = (String) requestList.getSelectionModel().getSelectedItem();
        if(selectedRequest != null && !selectedRequest.isEmpty()) {
            String requestId = selectedRequest.split(" ")[4];
            try {
                List<List<models.Match>> allMatches = BLManegment.getMatchedByRequestId(Integer.parseInt(requestId), amountTxt.getText());
                ObservableList offersItems = FXCollections.observableArrayList();
                offersItems.setAll(matchesToShow(allMatches));
                matchesList.setItems(offersItems);
            } catch (NumberFormatException e) {
                AlertHelper.showAlert(Alert.AlertType.ERROR, "You entered wrong input", e.getMessage());
            }
        }
    }

    public List<String> matchesToShow(List<List<models.Match>> matchesList) {
        List<String> strings = new ArrayList<>();
        int cost = 0;
        int fuel = 0;
        int minutesTaken = 0;

        for (List<models.Match> match: matchesList) {
            String s = "";
            cost = 0;
            fuel = 0;
            minutesTaken = 0;
            for(models.Match m : match) {
                cost += m.getCost();
                fuel += m.getAverageFuelConsumption();
                minutesTaken += m.getMinutesTaken();

                s += "Trip offer ID " + m.getOfferId() + "\nUp on stop " + m.getOriginStop() + ".\n";
                s += "Goes down in stop " + m.getDestinationStop() + ".\n";
            }

            TripRequest tripRequest = BLManegment.getTripRequest(match.get(0).getRequestId());

            int hour = tripRequest.getTripHour();
            int minuets = tripRequest.getTripMinute();

            if (tripRequest.getIsOut()) {
                hour += minutesTaken / 60;
                minuets += minutesTaken % 60;

                s += "We will arrive at " + hour + ":" + minuets + ".\n";
            } else {
                hour -= minutesTaken/60;
                minuets -= minutesTaken % 60;
                if(minuets < 0) {
                    hour--;
                    minuets = 60 + minuets;
                }
                s += "We will exit at " + hour + ":" + minuets + ".\n";
            }

            s += "The total trip minutes is: " + minutesTaken + ".\n";
            s += "The cost is: " + cost + ".\n";
            s += "The average fuel consumption is: " + fuel/match.size() + ".\n";

            strings.add(s);
        }

        if(strings.size() == 0) {
            strings.add("No matches found right now");
        }

        return strings;
    }

    @FXML
    public void match(ActionEvent event) throws IOException {
        int selectedMatchIndex = matchesList.getSelectionModel().getSelectedIndex();
        BLManegment.match(selectedMatchIndex);
        ((Stage) submitButton.getScene().getWindow()).close();
        showRating();
    }

    public void showRating() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader();
        URL url = getClass().getResource("./rate.fxml");
        fxmlLoader.setLocation(url);
        GridPane root = fxmlLoader.load(url.openStream());

        final Scene scene = new Scene(root, 700, 400);

        stage.setTitle("Rate your driver");
        stage.setScene(scene);
        stage.show();
    }
}
