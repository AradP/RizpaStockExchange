package ui;

import controllers.BLManegment;
import general.Constants;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class TripOffer extends Application implements Initializable {

    private Main mainController;

    @FXML
    public TextField hourField;

    @FXML
    public TextField minuteField;

    @FXML
    public TextField dayField;

    @FXML
    public TextField capacityField;

    @FXML
    public TextField ppkField;

    @FXML
    public ComboBox stopsCombo;

    @FXML
    public Label routeText;

    @FXML
    private TextField nameField;

    @FXML
    private ComboBox<String> timingCombo;

    @FXML
    private Button submitButton;

    private List<String> route = new ArrayList<>();

    @Override
    public void start(Stage stage) throws Exception {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        timingCombo.getItems().setAll(Constants.RECURRENCE_ONE_TIME,
                Constants.RECURRENCE_DAILY,
                Constants.RECURRENCE_DOUBLE_DAILY,
                Constants.RECURRENCE_WEEKLY,
                Constants.RECURRENCE_MONTHLY);

        timingCombo.getSelectionModel().selectFirst();

        List<String> stopsList = new ArrayList<>();

        BLManegment.getAllStops().forEach(stop -> {
            stopsList.add(stop.getName());
        });

        stopsCombo.getItems().setAll(stopsList);
    }

    @FXML
    public void addStopToRoute(ActionEvent event) {
        route.add(stopsCombo.getValue().toString());
        routeText.setText(routeText.getText() + " -> " + stopsCombo.getValue());
    }

    @FXML
    public void clearRoute(ActionEvent event) {
        route.clear();
        routeText.setText("Route : ");
    }

    @FXML
    protected void handleSubmitButtonAction(ActionEvent event) throws IOException {
        try {
            BLManegment.addTripOffer(nameField.getText(), route, dayField.getText(),
                    hourField.getText(), minuteField.getText(), timingCombo.getValue(),
                    ppkField.getText(), capacityField.getText());
            this.mainController.loadOffers();
            ((Stage) submitButton.getScene().getWindow()).close();
        } catch (NumberFormatException e) {
            AlertHelper.showAlert(Alert.AlertType.ERROR, "You entered wrong input", e.getMessage());
        }
    }

    public void setMainController(Main mainController) {
        this.mainController = mainController;
    }
}
