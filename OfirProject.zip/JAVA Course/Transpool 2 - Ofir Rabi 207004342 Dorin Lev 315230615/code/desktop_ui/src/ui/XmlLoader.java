package ui;

import controllers.BLManegment;
import exceptions.general.WrongHourException;
import exceptions.xml.*;
import javafx.scene.control.Alert;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

public abstract class XmlLoader {
    public static boolean loadXml(String path) {

        String message;

        try {
            BLManegment.loadXML(path);
            return true;
        } catch (NumberFormatException e) {
            message = ("Oops! the system supports only integer values");
        }
        catch (IncorrectFileTypeException e) {
            message = ("Oops! Please enter .xml file");
        } catch (ParserConfigurationException | SAXException | IOException | XPathExpressionException e) {
            message = ("Oops! We cant find the requested file");
        } catch (WrongMapBoundriesException e) {
            message = ("Wrong map boundries\nMake sure width and height are between 6 and 100");
        } catch (NotUniqueNameException e) {
            message = ("We have few stops with the same name\n");
            message += ("Stop " + e.getMessage() + " has already been declared" );
        } catch (NotUniqueLocationException e) {
            message = ("Stop " + e.getMessage() +  " has another stop in the same location");
        } catch (NotInMapBoundriesException e) {
            message = ("The location " + e.getMessage() + " is stop out of map boundries");
        } catch (UnexistingStopException e) {
            message = ("Path between " + e.getMessage() + " does not exist");
        } catch (NegativeNumberException e) {
            if (e.getMessage().isEmpty()){
                message = ("Unrecognized negative input");
            } else {
                message = (e.getMessage());
            }
        } catch (WrongHourException e) {
            message = ("Hour " + e.getMessage() + " is not between 0-23");
        } catch (WrongRecurrencesException e) {
            message = ("Recurrence " + e.getMessage() + " does not exist in the system");
        } catch (WrongRouteException e) {
            message = ("Route " + e.getMessage() + " is not valid");
        }

        AlertHelper.showAlert(Alert.AlertType.ERROR, "We have a map problem!",
                message);

        return false;
    }

}
