package ui;

import controllers.BLManegment;
import general.Constants;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Rate extends Application implements Initializable {

    @FXML
    public ComboBox timingCombo;
    @FXML
    public TextField descriptionTxt;

    @Override
    public void start(Stage stage) throws Exception {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        timingCombo.getItems().setAll(1,2,3,4,5);
    }

    @FXML
    public void submit(ActionEvent event) {
        if(timingCombo.getSelectionModel().getSelectedItem() != null) {
            BLManegment.rateDriver((Integer) timingCombo.getSelectionModel().getSelectedItem(), descriptionTxt.getText());
            ((Stage) timingCombo.getScene().getWindow()).close();
        }
    }
}
