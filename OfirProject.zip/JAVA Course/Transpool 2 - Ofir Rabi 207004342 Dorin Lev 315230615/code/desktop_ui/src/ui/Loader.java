package ui;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.stage.Stage;
import java.net.URL;
import java.util.ResourceBundle;

public class Loader extends Application implements Initializable {

    @FXML
    public ProgressBar loader;

    @Override
    public void start(Stage stage) throws Exception {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        loader.setVisible(true);
        loader.setProgress(ProgressBar.INDETERMINATE_PROGRESS);
    }
}
