package ui;

import controllers.BLManegment;
import general.Constants;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.TripRequest;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class TripRequestDetails extends Application implements Initializable {

    @FXML
    public Label idLbl;
    @FXML
    public Label ownerLbl;
    @FXML
    public Label originLbl;
    @FXML
    public Label destinationLbl;
    @FXML
    public Label timeLbl;
    @FXML
    public Label offersLbl;
    @FXML
    public Label costLbl;
    @FXML
    public Label timeMLbl;
    @FXML
    public Label fuelLbl;

    private Main mainController;

    @Override
    public void start(Stage stage) throws Exception {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        TripRequest tripRequest = BLManegment.getTripRequestToShow();

        idLbl.setText(String.valueOf(tripRequest.getId()));
        ownerLbl.setText(tripRequest.getName());
        originLbl.setText(tripRequest.getOriginStopName());
        destinationLbl.setText(tripRequest.getDestinationStopName());
        timeLbl.setText(BLManegment.getReqTime(tripRequest));
        if(BLManegment.isTripReqMatched(tripRequest)) {
            offersLbl.setVisible(true);
            offersLbl.setText(BLManegment.getOffersDetailsForReq(tripRequest));
        }


    }
}
