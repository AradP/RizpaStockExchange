package ui;

import controllers.BLManegment;
import general.Constants;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.TripOffer;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class TripOfferDetails extends Application implements Initializable {

    @FXML
    public Label idLbl;
    @FXML
    public Label ownerLbl;
    @FXML
    public Label routeLbl;
    @FXML
    public Label costLbl;
    @FXML
    public Label leavingLbl;
    @FXML
    public Label arrivalLbl;
    @FXML
    public Label fuelLbl;
    @FXML
    public Label stopsDetailsLbl;
    @FXML
    public Label ratingsLbl;

    @Override
    public void start(Stage stage) throws Exception {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        TripOffer tripOffer = BLManegment.getTripOfferToShow();
        idLbl.setText(String.valueOf(tripOffer.getId()));
        ownerLbl.setText(tripOffer.getOwner());
        routeLbl.setText(tripOffer.getRoute().getStops().toString());
        costLbl.setText(String.valueOf(BLManegment.calculateTripOfferCost(tripOffer)));
        leavingLbl.setText(tripOffer.getScheduling().getHourStart() + ":" + tripOffer.getScheduling().getMinuteStart());
        arrivalLbl.setText(BLManegment.getArrivalTimeForTripOffer(tripOffer));
        fuelLbl.setText((String.valueOf(BLManegment.calculateTripOfferFuel(tripOffer))));
        stopsDetailsLbl.setText(BLManegment.getStopsDetailsForTripOffer(tripOffer));
        ratingsLbl.setText(BLManegment.getDriverRatings(tripOffer));
    }
}
