package ui;

import com.fxgraph.graph.Graph;
import com.fxgraph.graph.PannableCanvas;
import controllers.BLManegment;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Main extends Application implements Initializable {

    @FXML
    public Slider slider;

    @FXML
    public Label timeLbl;

    @FXML
    public Button backBtn;

    @FXML
    public Button forwardBtn;

    @FXML
    public Button matchBtn;

    @FXML
    public Label dayLbl;

    @FXML
    Button loadXmlBtn;

    @FXML
    Button addTripRequestBtn;

    @FXML
    Button addTripOfferBtn;

    @FXML
    ListView offersList;

    @FXML
    ListView requestsList;

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader();
        URL url = getClass().getResource("main.fxml");
        fxmlLoader.setLocation(url);
        GridPane root = fxmlLoader.load(url.openStream());

        final Scene scene = new Scene(root, 700, 400);

        primaryStage.setTitle("Transpool");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void createMap(Scene scene) {
        Graph graphMap = new Graph();
        GraphMapHelper.initializeMap(graphMap);

        ScrollPane scrollPane = (ScrollPane) scene.lookup("#mapContainer");
        PannableCanvas canvas = graphMap.getCanvas();
        scrollPane.setContent(canvas);

        Platform.runLater(() -> {
            graphMap.getUseViewportGestures().set(false);
            graphMap.getUseNodeGestures().set(false);
        });
    }

    @FXML
    public void onLoadXmlClick(ActionEvent event) throws IOException {

        Stage stage = new Stage();
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("XML Files", "*.xml")
        );
        File selectedFile = fileChooser.showOpenDialog(stage);

        Task<Boolean> task = new Task<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                return XmlLoader.loadXml(selectedFile.getPath());
            }
        };

        Stage loaderStage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader();
        URL url = getClass().getResource("loader.fxml");
        fxmlLoader.setLocation(url);
        AnchorPane root = fxmlLoader.load(url.openStream());

        task.setOnRunning((e) -> {
            final Scene scene = new Scene(root, 300, 300);

            loaderStage.setTitle("Loading XML file...");
            loaderStage.setScene(scene);
            loaderStage.show();

        });

        task.setOnSucceeded((e) -> {
            loaderStage.close();
            AlertHelper.showAlert(Alert.AlertType.WARNING, "We have a Success!",
                    "Successful map loader");
            showContent(loadXmlBtn.getScene());
        });

        if (selectedFile != null) {
            new Thread(task).start();
        }
    }

    public void showContent(Scene scene) {
        createMap(scene);

        addTripOfferBtn.setDisable(false);
        addTripRequestBtn.setDisable(false);
        matchBtn.setDisable(false);
        backBtn.setDisable(false);
        forwardBtn.setDisable(false);

        loadOffers();
        loadRequests();
    }

    public void loadOffers() {
        ObservableList offersItems = FXCollections.observableArrayList();
        offersItems.setAll(BLManegment.getAllTripOffersToShow());
        offersList.setItems(offersItems);
    }

    public void loadRequests() {
        ObservableList requestsItems = FXCollections.observableArrayList();
        requestsItems.setAll(BLManegment.getAllTripRequestsToShow());
        requestsList.setItems(requestsItems);
    }

    @FXML
    public void onAddRequestClick(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader();
        URL url = getClass().getResource("tripRequest.fxml");
        fxmlLoader.setLocation(url);
        GridPane root = fxmlLoader.load(url.openStream());

        ((TripRequest)fxmlLoader.getController()).setMainController(this);

        final Scene scene = new Scene(root, 700, 400);

        stage.setTitle("Add trip request");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void onAddOfferClick(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader();
        URL url = getClass().getResource("tripOffer.fxml");
        fxmlLoader.setLocation(url);
        GridPane root = fxmlLoader.load(url.openStream());

        ((TripOffer)fxmlLoader.getController()).setMainController(this);

        final Scene scene = new Scene(root, 700, 400);

        stage.setTitle("Add trip offer");
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        slider.setMin(0);
        slider.setMax(4);
        slider.setBlockIncrement(1);
        slider.setMajorTickUnit(1);
        slider.valueProperty().addListener((observable, oldValue, newValue) -> changeTimeline(newValue));

        offersList.setOnMouseClicked(event -> {
            try {
                tripOfferClick();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        requestsList.setOnMouseClicked(event -> {
            try {
                tripRequestClick();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public void tripOfferClick() throws IOException {
        int offerId = Integer.parseInt(((String) offersList.getSelectionModel().getSelectedItem()).split(" ")[2]);
        BLManegment.setTripOfferToShow(offerId);

        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader();
        URL url = getClass().getResource("tripOfferDetails.fxml");
        fxmlLoader.setLocation(url);
        GridPane root = fxmlLoader.load(url.openStream());

//        ((TripOfferDetails)fxmlLoader.getController()).setMainController(this);

        final Scene scene = new Scene(root, 700, 700);

        stage.setTitle("Trip Offer Details");
        stage.setScene(scene);
        stage.show();
    }

    public void tripRequestClick() throws IOException {
        int offerId = Integer.parseInt(((String) requestsList.getSelectionModel().getSelectedItem()).split(" ")[4]);
        BLManegment.setTripRequestToShow(offerId);

        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader();
        URL url = getClass().getResource("tripRequestDetails.fxml");
        fxmlLoader.setLocation(url);
        GridPane root = fxmlLoader.load(url.openStream());

//        ((TripOfferDetails)fxmlLoader.getController()).setMainController(this);

        final Scene scene = new Scene(root, 700, 700);

        stage.setTitle("Trip Request Details");
        stage.setScene(scene);
        stage.show();
    }

    public void changeTimeline(Number value) {
        switch (value.intValue()) {
            case 0:
                timeLbl.setText("Progress : 5 Minutes");
                break;
            case 1:
                timeLbl.setText("Progress : 30 Minutes");
                break;
            case 2:
                timeLbl.setText("Progress : 1 Hour");
                break;
            case 3:
                timeLbl.setText("Progress : 2 Hours");
                break;
            case 4:
                timeLbl.setText("Progress : 1 Day");
                break;
        }
    }

    public void onBackClick(ActionEvent event) {
        int minuteAdding = 0;
        switch ((int) slider.getValue()) {
            case 0:
                minuteAdding = -5;
                break;
            case 1:
                minuteAdding = -30;
                break;
            case 2:
                minuteAdding = -60;
                break;
            case 3:
                minuteAdding = -120;
                break;
            case 4:
                minuteAdding = -24*60;
                break;
        }

        BLManegment.changeCurrentMinute(minuteAdding);
        dayLbl.setText(getCurrentTime());
        createMap(backBtn.getScene());
    }

    public void onForwardClick(ActionEvent event) {
        int minuteAdding = 0;
        switch ((int) slider.getValue()) {
            case 0:
                minuteAdding = 5;
                break;
            case 1:
                minuteAdding = 30;
                break;
            case 2:
                minuteAdding = 60;
                break;
            case 3:
                minuteAdding = 120;
                break;
            case 4:
                minuteAdding = 24*60;
                break;
        }

        BLManegment.changeCurrentMinute(minuteAdding);
        dayLbl.setText(getCurrentTime());
        createMap(forwardBtn.getScene());
    }

    public String getCurrentTime() {
        int hours = BLManegment.getCurrentMinute() % (24 * 60) / 60;
        int minutes = BLManegment.getCurrentMinute() % (24 * 60) % 60;
        return (BLManegment.getCurrentMinute() / (24 * 60) + 1) + ", " +
                ("00" + hours).substring(String.valueOf(hours).length()) + ":" +
                ("00" + minutes).substring(String.valueOf(minutes).length());
    }

    public void onMatchClick(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader();
        URL url = getClass().getResource("match.fxml");
        fxmlLoader.setLocation(url);
        GridPane root = fxmlLoader.load(url.openStream());

        ((Match)fxmlLoader.getController()).setMainController(this);

        final Scene scene = new Scene(root, 700, 400);

        stage.setTitle("Match");
        stage.setScene(scene);
        stage.show();
    }
}
