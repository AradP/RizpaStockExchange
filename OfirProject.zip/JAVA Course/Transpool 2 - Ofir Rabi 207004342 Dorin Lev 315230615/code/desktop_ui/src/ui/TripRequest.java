package ui;

import controllers.BLManegment;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class TripRequest extends Application implements Initializable {

    private Main mainController;

    @FXML
    public TextField hourField;

    @FXML
    public TextField minuteField;

    @FXML
    public TextField dayField;

    @FXML
    private TextField nameField;

    @FXML
    private ComboBox<String> originCombo;

    @FXML
    private ComboBox<String> destCombo;

    @FXML
    private RadioButton arrivalBtn;

    @FXML
    private RadioButton outBtn;

    @FXML
    private Button submitButton;

    @Override
    public void start(Stage stage) throws Exception {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<String> stopsList = new ArrayList<>();

        BLManegment.getAllStops().forEach(stop -> {
            stopsList.add(stop.getName());
        });

        originCombo.getItems().setAll(stopsList);
        destCombo.getItems().setAll(stopsList);

        originCombo.getSelectionModel().selectFirst();
        destCombo.getSelectionModel().selectFirst();
    }

    @FXML
    protected void handleSubmitButtonAction(ActionEvent event) throws IOException {
        try {
            BLManegment.addTripRequest(nameField.getText(), originCombo.getValue(), destCombo.getValue(),
                    dayField.getText(), hourField.getText(), minuteField.getText(), outBtn.isSelected());
            this.mainController.loadRequests();
            ((Stage) submitButton.getScene().getWindow()).close();
        } catch (NumberFormatException e) {
            AlertHelper.showAlert(Alert.AlertType.ERROR, "You entered wrong input", e.getMessage());
        }

    }

    public void setMainController(Main mainController) {
        this.mainController = mainController;
    }
}
