package db;

import models.Stop;
import java.util.ArrayList;
import java.util.List;

public class Stops {
    private static List<Stop> stops = new ArrayList<>();

    public static List<Stop> getStops() {
        return Stops.stops;
    }

    public static void addStops(List<Stop> newStops) {
        stops.addAll(newStops);
    }

    public static Stop getStop(String stopName) {
        for (Stop currentStop: Stops.stops ) {
            if(currentStop.getName().equals(stopName)){
                return currentStop;
            }
        }

        return null;
    }

    public static Stop getStop(int stopId) {
        for (Stop currentStop: Stops.stops ) {
            if(currentStop.getId() == stopId){
                return currentStop;
            }
        }

        return null;
    }

    public static void clearStops() {
        Stops.stops = new ArrayList<>();
    }
}
