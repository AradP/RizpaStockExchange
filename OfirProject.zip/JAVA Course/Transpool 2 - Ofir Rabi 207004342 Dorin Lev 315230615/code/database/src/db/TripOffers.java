package db;

import models.Path;
import models.TripOffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class TripOffers {
    private static List<TripOffer> tripOffers = new ArrayList<>();

    public static List<TripOffer> getTripOffers() {
        return TripOffers.tripOffers;
    }

    public static void setTripOffers(List<TripOffer> tripOffers) {
        TripOffers.tripOffers = tripOffers;
    }

    public static TripOffer getOffer(int id) {
        for (TripOffer currentOffer: TripOffers.getTripOffers() ) {
            if(currentOffer.getId() == id){
                return currentOffer;
            }
        }

        return null;
    }

    public static void addNewOffer(TripOffer tripOffer){
        tripOffers.add(tripOffer);
    }

    public static void addTripOffers(List<TripOffer> newTripOffers) { tripOffers.addAll(newTripOffers); }

    public static void clearOffers() {
        TripOffers.tripOffers = new ArrayList<>();
    }

    public static List<TripOffer> getBySubRoute(List<String> subroute) {
        return tripOffers.stream().filter(tripOffer ->
            Collections.indexOfSubList(tripOffer.getRoute().getStops() , subroute) != -1
        ).collect(Collectors.toList());
    }

    public static int calculateTripOfferCost (TripOffer tripOffer){
        int cost = 0;

        for (int i = 0; i < tripOffer.getRoute().getStops().size(); i++){
            Path path = Paths.getPath(tripOffer.getRoute().getStops().get(i),tripOffer.getRoute().getStops().get(i+1));
            cost += path.getLength() * tripOffer.getPpk();
        }

        return cost;
    }



}
