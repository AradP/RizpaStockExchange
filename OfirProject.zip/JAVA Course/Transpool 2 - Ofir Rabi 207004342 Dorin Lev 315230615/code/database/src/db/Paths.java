package db;

import models.Path;
import models.TripOffer;

import java.util.ArrayList;
import java.util.List;

public class Paths {
    private static List<Path> paths = new ArrayList<>();

    public static List<Path> getPaths() {
        return Paths.paths;
    }

    public static void addPaths(List<Path> newPaths) {
        paths.addAll(newPaths);
    }

    public static Path getPath(String from, String to) {
        return Paths.getPaths().stream().filter(path -> (path.getFrom().equals(from) && path.getTo().equals(to)) ||
                (!path.isOneWay() && path.getFrom().equals(to) && path.getTo().equals(from)))
                .findFirst().orElse(null);
    }

    public static void clearPaths() {
        Paths.paths = new ArrayList<>();
    }

//    public static int getCostBetween(TripOffer tripOffer, int from, int to){
//        int cost = 0;
//
//        for (int i = from; i < to - 1; i++){
//            cost  += Paths.getPath(tripOffer.getRoute().getStops().get(i),tripOffer.getRoute().getStops().get(i+1)).getLength() * tripOffer.getPpk();
//        }
//
//        return cost;
//    }
}
