package constants;

public abstract class Recurrence {
    public static final String ONE_TIME = "OneTime";
    public static final String DAILY = "Daily";
    public static final String DOUBLE_DAILY = "BiDaily";
    public static final String WEEKLY = "Weekly";
    public static final String MONTHLY = "Monthly";
}
