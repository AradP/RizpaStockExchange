package models;

public class TripOfferWithStop {
    private TripOffer tripOffer;
    private Stop stop;

    public TripOfferWithStop(TripOffer tripOffer, Stop stop) {
        this.tripOffer = tripOffer;
        this.stop = stop;
    }

    public TripOffer getTripOffer() {
        return tripOffer;
    }

    public void setTripOffer(TripOffer tripOffer) {
        this.tripOffer = tripOffer;
    }

    public Stop getStop() {
        return stop;
    }

    public void setStop(Stop stop) {
        this.stop = stop;
    }
}
