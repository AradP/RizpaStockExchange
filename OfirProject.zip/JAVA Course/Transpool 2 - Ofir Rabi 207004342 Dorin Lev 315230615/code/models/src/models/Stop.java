package models;

public class Stop {

    private static int idCounter = 0;
    private int id;
    private String name;
    private int x;
    private int y;

    public Stop(String name, int x, int y) {
        this.id = idCounter++;
        this.name = name;
        this.x = x;
        this.y = y;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
