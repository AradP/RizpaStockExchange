package models;

import java.util.ArrayList;
import java.util.List;

public class Route {

    private List<String> stopsList = new ArrayList<>();

    public Route(String stopsString) {
        for (String s : stopsString.split(",")) {
            this.stopsList.add(s.trim());
        }
    }

    public Route(List<String> stopsList) {
        this.stopsList = stopsList;
    }


    public List<String> getStops() {
        return this.stopsList;
    }

    @Override
    public String toString() {
        return String.join(", ", this.stopsList);
    }
}
