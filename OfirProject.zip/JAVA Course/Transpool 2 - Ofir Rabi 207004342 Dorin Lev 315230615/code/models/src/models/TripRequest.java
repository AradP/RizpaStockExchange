package models;

public class TripRequest {

    private static int requestID = 1;
    private int id;
    private String name;
    private String originStopName;
    private String destinationStopName;
    private int tripDay;
    private int tripHour;
    private int tripMinute;
    private boolean isOut;

    public TripRequest(String name, String originStopName, String destinationStopName, int tripDay, int tripHour, int tripMinute, boolean isOut) {
        this.id = requestID++;
        this.name = name;
        this.originStopName = originStopName;
        this.destinationStopName = destinationStopName;
        this.tripHour = tripHour;
        this.tripMinute = tripMinute;
        this.isOut = isOut;
        this.tripDay = tripDay;
    }

    public int getTripDay() {
        return this.tripDay;
    }

    public int getId() { return id; }

    public String getName() { return name; }

    public String getOriginStopName() { return originStopName; }

    public String getDestinationStopName() { return destinationStopName; }

    public int getTripHour() { return tripHour; }

    public int getTripMinute() { return tripMinute; }

    public boolean getIsOut() { return isOut; }
}
