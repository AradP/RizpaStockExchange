package models;

import java.util.ArrayList;
import java.util.List;

public class TripOffer {

    private static int idCounter = 1;
    private int id;
    private String owner;
    private int capacity;
    private int ppk;
    private Route route;
    private Scheduling scheduling;
    private List<Integer> ratings;
    private List<String> ratingDescs;

    public TripOffer(String owner, int capacity, int ppk, Route route, Scheduling scheduling) {
        this.owner = owner;
        this.capacity = capacity;
        this.ppk = ppk;
        this.route = route;
        this.scheduling = scheduling;
        this.id = TripOffer.idCounter++;
        this.ratings = new ArrayList<>();
        this.ratingDescs = new ArrayList<>();
    }

    public List<Integer> getRatings() {
        return ratings;
    }

    public List<String> getRatingDescs() {
        return ratingDescs;
    }

    public void addRating(int rating) {
        this.ratings.add(rating);
    }

    public void addRatingDesc(String rating) {
        this.ratingDescs.add(rating);
    }

    public int getId() {
        return id;
    }

    public String getOwner() {
        return owner;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getPpk() {
        return ppk;
    }

    public Route getRoute() { return route; }

    public Scheduling getScheduling() { return scheduling; }


}
