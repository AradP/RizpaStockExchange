package xml;

import general.Constants;
import exceptions.xml.*;
import models.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class XmlLoader {

    private XPathExpression expressionComplier;
    private XPath expressionBuilder;
    private Document xmlDocument;

    public XmlLoader (String pathFile) throws IncorrectFileTypeException,
                                              ParserConfigurationException,
                                              IOException,
                                              SAXException {
//      We will put our xml document in it
        this.xmlDocument = null;

//      The expressionBuilder helps us to do queries on the xml document
        XPathFactory xpathFactory = XPathFactory.newInstance();
        this.expressionBuilder = xpathFactory.newXPath();

//      The expressionComplier compile the expression from the expressionBuilder
        this.expressionComplier = null;

        XmlValidations.checkDocumentIsXML(pathFile);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder;

        builder = factory.newDocumentBuilder();
        this.xmlDocument = builder.parse(pathFile);
    }

    public MapBoundries parseMapBoundries() throws XPathExpressionException, NumberFormatException {
        MapBoundries mapBoundries;
        expressionComplier = expressionBuilder.compile("//TransPool/MapDescriptor/MapBoundries");
        Node currentNode = (Node)expressionComplier.evaluate(xmlDocument, XPathConstants.NODE);

        mapBoundries = new MapBoundries(Integer.parseInt(currentNode.getAttributes().getNamedItem("length").getNodeValue()),
                Integer.parseInt(currentNode.getAttributes().getNamedItem("width").getNodeValue()));

        return mapBoundries;
    }

    public List<Stop> parseStops() throws XPathExpressionException, NumberFormatException {
        List<Stop> stops = new ArrayList<>();
        expressionComplier = expressionBuilder.compile("//TransPool/MapDescriptor/Stops/Stop");
        NodeList allStops = (NodeList)expressionComplier.evaluate(xmlDocument, XPathConstants.NODESET);

        for(int i = 0; i < allStops.getLength(); i++) {
            stops.add(new Stop(allStops.item(i).getAttributes().getNamedItem("name").getNodeValue().trim(),
                               Integer.parseInt(allStops.item(i).getAttributes().getNamedItem("x").getNodeValue()),
                               Integer.parseInt(allStops.item(i).getAttributes().getNamedItem("y").getNodeValue())));
        }

        return stops;
    }

    public List<Path> parsePaths() throws XPathExpressionException, NumberFormatException {
        boolean oneWay;
        List<Path> paths = new ArrayList<>();
        expressionComplier = expressionBuilder.compile("//TransPool/MapDescriptor/Paths/Path");
        NodeList allPaths = (NodeList)expressionComplier.evaluate(xmlDocument, XPathConstants.NODESET);

        for(int i = 0; i < allPaths.getLength(); i++) {

            oneWay = false;

            if(allPaths.item(i).getAttributes().getNamedItem("one-way") != null) {
                oneWay = Boolean.parseBoolean(allPaths.item(i).getAttributes().getNamedItem("one-way").getNodeValue());
            }

            paths.add(new Path(allPaths.item(i).getAttributes().getNamedItem("from").getNodeValue(),
                    allPaths.item(i).getAttributes().getNamedItem("to").getNodeValue(),
                    oneWay,
                    Integer.parseInt(((Element)allPaths.item(i)).getElementsByTagName("Length").item(0).getTextContent()),
                    Integer.parseInt(((Element)allPaths.item(i)).getElementsByTagName("FuelConsumption").item(0).getTextContent()),
                    Integer.parseInt(((Element)allPaths.item(i)).getElementsByTagName("SpeedLimit").item(0).getTextContent())));
        }

        return paths;
    }

    public List<TripOffer> parseTripOffers() throws XPathExpressionException, NumberFormatException {

        Element element;
        List<TripOffer> transPoolTrips = new ArrayList<>();
        Route route;
        Scheduling scheduling;
        String owner;
        int capacity;
        int ppk;

//      Build PlannedTrips object
        this.expressionComplier = expressionBuilder.compile("/TransPool/PlannedTrips/TransPoolTrip");
        NodeList trips = (NodeList) this.expressionComplier.evaluate(this.xmlDocument, XPathConstants.NODESET);

        for (int i = 0; i < trips.getLength() ; i++) {
            element = (Element) trips.item(i);

            owner = setOwnerFromXML(element);
            capacity = setCapacityFromXML(element);
            ppk = setPPKFromXML(element);
            route = setRouteFromXML(element);
            scheduling = setSchedualingFromXML(element);

            transPoolTrips.add(new TripOffer(owner,
                                             capacity,
                                             ppk,
                                             route,
                                             scheduling));
        }

        return transPoolTrips;
    }

    public Scheduling setSchedualingFromXML (Element element) throws NumberFormatException{

        String recurrences;
        int dayStart = 1;

//      Checks if there is no "recurrences" attribute
        if ( element.getElementsByTagName("Scheduling")
                .item(0).getAttributes()
                .getNamedItem("recurrences") == null) {

            recurrences = Constants.RECURRENCE_ONE_TIME;
        } else {
            recurrences = element.getElementsByTagName("Scheduling")
                    .item(0).getAttributes()
                    .getNamedItem("recurrences")
                    .getTextContent();

            if (element.getElementsByTagName("Scheduling")
                       .item(0)
                       .getAttributes()
                       .getNamedItem("day-start") != null) {
                dayStart = Integer.parseInt(element.getElementsByTagName("Scheduling")
                        .item(0)
                        .getAttributes()
                        .getNamedItem("day-start")
                        .getTextContent());
                if(dayStart < 1) {

                }
            } else {

            }
        }

        return new Scheduling( Integer.parseInt(element.getElementsByTagName("Scheduling")
                .item(0)
                .getAttributes()
                .getNamedItem("hour-start")
                .getTextContent()),
                0,
                dayStart,
                recurrences);

    }

    public Route setRouteFromXML (Element element){
        Route route;

        route = new Route(element.getElementsByTagName("Route")
                .item(0)
                .getAttributes()
                .getNamedItem("path")
                .getTextContent());

        return route;
    }

    public int setPPKFromXML (Element element) throws NumberFormatException{

        int ppk;

        ppk = Integer.parseInt(element.getElementsByTagName("PPK").item(0).getTextContent());

        return ppk;
    }

    public int setCapacityFromXML (Element element) throws NumberFormatException{

        int capacity;

        capacity = Integer.parseInt(element.getElementsByTagName("Capacity").item(0).getTextContent());

        return capacity;
    }

    public String setOwnerFromXML (Element element){

        String owner;

        owner = element.getElementsByTagName("Owner").item(0).getTextContent();

        return owner;
    }

}
