package controllers;

import db.Matches;
import db.TripOffers;
import db.TripRequests;
import models.Match;
import models.TripRequest;
import java.util.ArrayList;
import java.util.List;

public class TripRequestsController {

    public static List<String> getUnmatchedRequests() {
        List<String> tripRequests = new ArrayList<>();
        String currentRequestText;

        for(TripRequest currentRequest : TripRequests.getTripRequests()) {

            if(Matches.getAllByRequestId(currentRequest.getId()).size() == 0) {
                currentRequestText = "";

                currentRequestText += "Details of trip request " + currentRequest.getId() + " \n";
                currentRequestText += "Owner: " + currentRequest.getName() + "\n";
                currentRequestText += "From stop " + currentRequest.getOriginStopName() + " to stop " +  currentRequest.getDestinationStopName() + "\n";

                if (currentRequest.getIsOut()) {
                    currentRequestText += "Leaves at ";
                } else {
                    currentRequestText += "Arrives at ";
                }
                currentRequestText += getTimeFormat(currentRequest.getTripHour(), currentRequest.getTripMinute()) + "\n";

                tripRequests.add(currentRequestText);
            }

        }

        return tripRequests;
    }

    public static List<String> getAllTripRequests() {
        List<String> tripRequests = new ArrayList<>();
        String currentRequestText;

        for (TripRequest currentRequest: TripRequests.getTripRequests()) {
            currentRequestText = "";

            currentRequestText += "Details of trip request " + currentRequest.getId() + " \n";
            currentRequestText += "Owner: " + currentRequest.getName() + "\n";
            currentRequestText += "From stop " + currentRequest.getOriginStopName() + " to stop " +  currentRequest.getDestinationStopName() + "\n";

            if (currentRequest.getIsOut()) {
                currentRequestText += "Leaves at ";
            } else {
                currentRequestText += "Arrives at ";
            }
            currentRequestText += getTimeFormat(currentRequest.getTripHour(), currentRequest.getTripMinute()) + "\n";

            tripRequests.add(currentRequestText);
        }

        return tripRequests;
    }

    private static String timeFormatToMatch(int hourStart, int minuteStart, int addMinutes) {
        return getTimeFormat((hourStart + addMinutes / 60) ,(minuteStart + addMinutes % 60));
    }

    private static String getTimeFormat(int hours, int minutes) {
        return ("00" + hours).substring(String.valueOf(hours).length()) + ":" +
                ("00" + minutes).substring(String.valueOf(minutes).length());
    }

    public static void addTripRequest(TripRequest tripRequest) {
        TripRequests.addTripRequest(tripRequest);
    }
}
