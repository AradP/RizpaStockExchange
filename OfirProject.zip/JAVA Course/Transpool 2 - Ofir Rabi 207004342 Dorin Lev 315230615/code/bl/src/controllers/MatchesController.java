package controllers;

import db.*;
import models.*;
import java.util.ArrayList;
import java.util.List;

public class MatchesController {

    private static ArrayList<Integer>[] adjList;
    private static List<List<Integer>> allPossiblePaths;

    private static void setEdges() {
        adjList = new ArrayList[Stops.getStops().size()];
        for(Stop originStop : Stops.getStops()) {
            adjList[originStop.getId()] = new ArrayList<>();
            for(Stop destinationStop : Stops.getStops()) {
                Path path = Paths.getPath(originStop.getName(), destinationStop.getName());
                if(path != null) {
                    adjList[originStop.getId()].add(destinationStop.getId());
                }
            }
        }
    }

    public static List<List<Integer>> getAllPaths(int s, int d)
    {
        boolean[] isVisited = new boolean[Stops.getStops().size()];
        setEdges();
        allPossiblePaths = new ArrayList<>();
        ArrayList<Integer> pathList = new ArrayList<>();

        //add source to path[]
        pathList.add(s);

        //Call recursive utility
        printAllPathsUtil(s, d, isVisited, pathList);

        return allPossiblePaths;
    }

    private static void printAllPathsUtil(Integer u, Integer d,
                                   boolean[] isVisited,
                                   List<Integer> localPathList) {

        // Mark the current node
        isVisited[u] = true;

        if (u.equals(d))
        {
            allPossiblePaths.add(new ArrayList<>(localPathList));
            // if match found then no need to traverse more till depth
            isVisited[u]= false;
            return ;
        }

        // Recur for all the vertices
        // adjacent to current vertex
        for (Integer i : adjList[u])
        {
            if (!isVisited[i])
            {
                // store current node
                // in path[]
                localPathList.add(i);
                printAllPathsUtil(i, d, isVisited, localPathList);

                // remove current node
                // in path[]
                localPathList.remove(i);
            }
        }

        // Mark the current node
        isVisited[u] = false;
    }
}
