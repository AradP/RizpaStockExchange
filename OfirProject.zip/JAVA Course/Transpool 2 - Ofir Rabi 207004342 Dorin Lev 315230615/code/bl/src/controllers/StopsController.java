package controllers;

import db.Stops;
import models.Stop;

import java.util.ArrayList;
import java.util.List;

public class StopsController {
    public static List<String> getStopsNames() {
        List<String> stops = new ArrayList<>();

        for(Stop stop : Stops.getStops()) {
            stops.add(stop.getName());
        }

        return stops;
    }

    public static Stop getStopByName(String stopName){
        return Stops.getStop(stopName);
    }

    public static void addStops(List<Stop> newStops) {
        Stops.addStops(newStops);
    }

    public static List<Stop> getAllStops() {
        return Stops.getStops();
    }
}
