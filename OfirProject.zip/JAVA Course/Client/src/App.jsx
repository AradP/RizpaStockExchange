import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import routes from "./routes.jsx";
import SignUpPage from "./components/SignUpPage";

function App() {
  const pages = routes.map((route) => (
    <Route key={route.path} exact path={route.path}>
      {route.page}
    </Route>
  ));
  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      <Router>
        <Switch>
          {pages}
          {/* Default route if there is no match */}
          <Route path="*" component={SignUpPage} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
