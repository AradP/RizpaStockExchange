import React from "react";
import SignUpPage from "./components/SignUpPage";
import MapsPage from "./components/MapsPage";
import MapDetailPage from "./components/MapDetailPage";

const routes = [
  {
    path: "/",
    page: <SignUpPage />,
  },
  {
    path: "/maps/:userName/:role",
    page: <MapsPage />,
  },
  {
    path: "/mapDetail/:mapName/:role/:userName",
    page: <MapDetailPage />,
  },
];

export default routes;
