import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@material-ui/core";
import RoutesBuilder from "../components/RoutesBuilder";
import { useParams } from "react-router-dom";
import $ from "jquery";

const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(1),
  },
  back: {},
  alignAll: {
    display: "block",
  },
  center: {
    display: "flex",
    justifyContent: "center",
    margin: "20px",
  },
  button: {
    display: "block",
    marginTop: theme.spacing(2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
}));

function TripOfferPopup({
  openDialog,
  setOpenDialog,
  stationNames,
  setTripOffers,
  mapName,
}) {
  const classes = useStyles();
  const { userName } = useParams();
  const [reacurance, setReacurance] = React.useState("");
  const [hour, setHour] = React.useState("");
  const [minutes, setMinutes] = React.useState("");
  const [openReacurance, setReacuranceOpen] = React.useState(false);
  const [openHour, setHourOpen] = React.useState(0);
  const [openMinutes, setMinutesOpen] = React.useState(0);
  const [currRoute, setCurrRoute] = React.useState([]);
  const [offerName, setOfferName] = React.useState(userName);
  const [offerPassangers, setOfferPassangers] = React.useState(0);
  const [offerPrice, setOfferPrice] = React.useState(0);

  const handleDialogClose = () => {
    setOpenDialog(false);
  };

  const handleReacuranceChange = (event) => {
    setReacurance(event.target.value);
  };

  const handleReacuranceClose = () => {
    setReacuranceOpen(false);
  };

  const handleReacuranceOpen = () => {
    setReacuranceOpen(true);
  };

  const handleHourChange = (event) => {
    setHour(event.target.value);
  };

  const handleHourClose = () => {
    setHourOpen(false);
  };

  const handleHourOpen = () => {
    setHourOpen(true);
  };

  const handleMinutesChange = (event) => {
    setMinutes(event.target.value);
  };

  const handleMinutesClose = () => {
    setMinutesOpen(false);
  };

  const handleMinutesOpen = () => {
    setMinutesOpen(true);
  };

  const handleOfferNameChange = (event) => {
    setOfferName(event.target.value);
  };

  const handlePassangersChange = (event) => {
    setOfferPassangers(event.target.value);
  };
  const handlePriceChange = (event) => {
    setOfferPrice(event.target.value);
  };

  const addOffer = () => {
    var formData = new FormData();
    let routes = "";
    currRoute.forEach((route) => {
      routes += route.name + ",";
    });
    routes = routes.substring(0, routes.length - 1);
    formData.append("mapName", mapName);
    formData.append("name", offerName);
    formData.append("route", routes);
    formData.append("passangers", offerPassangers.toString());
    formData.append("price", offerPrice.toString());
    formData.append("reacurance", reacurance);
    formData.append("hour", hour);
    formData.append("minutes", minutes);
    console.log(formData);
    $.ajax({
      method: "POST",
      data: formData,
      url: "/web_app_war/tripOffer",
      processData: false, // Don't process the files
      contentType: false, // Set content type to false as jQuery will tell the server its a query string request
      timeout: 4000,
      error: function (e) {
        alert("Please fill all details");
      },
      success: function (data) {
        setTripOffers(data);
        setOpenDialog(false);
      },
    });
  };

  return (
    <div style={{ width: "100%" }}>
      <Dialog
        open={openDialog}
        onClose={handleDialogClose}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Add</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Fill the following details to add a new trip offer
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            id="offerName"
            label="Name"
            type="string"
            fullWidth
            required="true"
            value={offerName}
            onChange={handleOfferNameChange}
          />
          <RoutesBuilder
            stationNames={stationNames}
            setCurrRoute={setCurrRoute}
          ></RoutesBuilder>
          <TextField
            autoFocus
            margin="dense"
            id="passangers"
            label="Passangers"
            type="number"
            fullWidth
            required="true"
            value={offerPassangers}
            onChange={handlePassangersChange}
          />
          <TextField
            autoFocus
            margin="dense"
            id="price"
            label="Price"
            type="number"
            fullWidth
            required="true"
            value={offerPrice}
            onChange={handlePriceChange}
          />
          <FormControl className={classes.formControl}>
            <InputLabel id="demo-controlled-open-select-label">
              Reacurancess
            </InputLabel>
            <Select
              labelId="demo-controlled-open-select-label"
              id="demo-controlled-open-select"
              open={openReacurance}
              onClose={handleReacuranceClose}
              onOpen={handleReacuranceOpen}
              value={reacurance}
              onChange={handleReacuranceChange}
            >
              <MenuItem value={"OneTime"}>One Time</MenuItem>
              <MenuItem value={"Daily"}>Daily</MenuItem>
              <MenuItem value={"BiDaily"}>BiDaily</MenuItem>
              <MenuItem value={"Weekly"}>Weekly</MenuItem>
              <MenuItem value={"Monthly"}>Monthly</MenuItem>
            </Select>
          </FormControl>
          <FormControl className={classes.formControl}>
            <InputLabel id="Hour">Hour</InputLabel>
            <Select
              labelId="Hour"
              id="Hour"
              open={openHour}
              onClose={handleHourClose}
              onOpen={handleHourOpen}
              value={hour}
              onChange={handleHourChange}
            >
              <MenuItem value={"00"}>00</MenuItem>
              <MenuItem value={"01"}>01</MenuItem>
              <MenuItem value={"02"}>02</MenuItem>
              <MenuItem value={"03"}>03</MenuItem>
              <MenuItem value={"04"}>04</MenuItem>
              <MenuItem value={"05"}>05</MenuItem>
              <MenuItem value={"06"}>06</MenuItem>
              <MenuItem value={"07"}>07</MenuItem>
              <MenuItem value={"08"}>08</MenuItem>
              <MenuItem value={"09"}>09</MenuItem>
              <MenuItem value={"10"}>10</MenuItem>
              <MenuItem value={"11"}>11</MenuItem>
              <MenuItem value={"12"}>12</MenuItem>
            </Select>
          </FormControl>

          <FormControl className={classes.formControl}>
            <InputLabel id="Minutes">Minutes</InputLabel>
            <Select
              labelId="Minutes"
              id="Minutes"
              open={openMinutes}
              onClose={handleMinutesClose}
              onOpen={handleMinutesOpen}
              value={minutes}
              onChange={handleMinutesChange}
            >
              <MenuItem value={"00"}>00</MenuItem>
              <MenuItem value={"05"}>05</MenuItem>
              <MenuItem value={"10"}>10</MenuItem>
              <MenuItem value={"15"}>15</MenuItem>
              <MenuItem value={"20"}>20</MenuItem>
              <MenuItem value={"25"}>25</MenuItem>
              <MenuItem value={"30"}>30</MenuItem>
              <MenuItem value={"35"}>35</MenuItem>
              <MenuItem value={"40"}>40</MenuItem>
              <MenuItem value={"45"}>45</MenuItem>
              <MenuItem value={"50"}>50</MenuItem>
              <MenuItem value={"55"}>55</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose} color="primary">
            Cancel
          </Button>
          <Button onClick={addOffer} color="primary">
            Add
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default TripOfferPopup;
