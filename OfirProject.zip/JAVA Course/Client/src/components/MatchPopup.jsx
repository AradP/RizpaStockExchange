import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@material-ui/core";
import RoutesBuilder from "../components/RoutesBuilder";
import { useParams } from "react-router-dom";
import $ from "jquery";

const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(1),
  },
  back: {},
  alignAll: {
    display: "block",
  },
  center: {
    display: "flex",
    justifyContent: "center",
    margin: "20px",
  },
  button: {
    display: "block",
    marginTop: theme.spacing(2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
}));

function TripOfferPopup({
  openDialog,
  setOpenDialog,
  requestId,
  stationNames,
  setTripOffers,
}) {
  const classes = useStyles();

  const { mapName } = useParams();

  const loadMatches = async () => {
    fetch("/web_app_war/match?request=" + requestId + "&map=" + mapName, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
      })
      .catch((error) => console.log("ERROR"));
  };

  React.useEffect(() => {
    loadMatches();
  }, []);

  return (
    <div style={{ width: "100%" }}>
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Match Offers</DialogTitle>
        <DialogContent>
          <DialogContentText>There are no matches found...</DialogContentText>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default TripOfferPopup;
