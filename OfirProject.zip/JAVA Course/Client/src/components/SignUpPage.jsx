import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Input from "@material-ui/core/Input";
import InputLabel from "@material-ui/core/InputLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
import FormControl from "@material-ui/core/FormControl";
import AccountCircle from "@material-ui/icons/AccountCircle";
import Radio from "@material-ui/core/Radio";
import Button from "@material-ui/core/Button";
import { Grid } from "@material-ui/core";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Typography from "@material-ui/core/Typography";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(1),
  },
  back: {},
  alignAll: {
    display: "block",
  },
  center: {
    display: "flex",
    justifyContent: "center",
    margin: "20px",
  },
}));

function SignUpPage() {
  const classes = useStyles();
  const history = useHistory();

  const [role, setRole] = React.useState("");
  const handleRoleChange = (event) => {
    setRole(event.target.value);
  };
  const [disable, setDisable] = React.useState(true);

  const [userName, setUserName] = React.useState("");
  const handleUserNameChange = (event) => {
    setUserName(event.target.value);
  };

  const onSignUpClick = () => {
    const url = "/web_app_war/user?user=" + userName + "&role=" + role;
    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    })
      .then((response) => response.json())
      .then((isAdded) => {
        if (isAdded) {
          history.push("/maps/" + userName + "/" + role);
        } else {
          alert("User already exist");
        }
      })
      .catch((error) => alert("There was an error "));
  };

  React.useEffect(() => {
    setDisable(userName === "" || role === "");
  }, [userName, role]);

  return (
    <Grid container spacing={1} className={classes.alignAll}>
      <Grid item>
        <Typography variant="h3" className={classes.center}>
          Let's get started
        </Typography>
      </Grid>
      <Grid item className={classes.center}>
        <FormControl>
          <InputLabel htmlFor="input">User Name</InputLabel>
          <Input
            id="input"
            value={userName}
            onChange={handleUserNameChange}
            startAdornment={
              <InputAdornment position="start">
                <AccountCircle />
              </InputAdornment>
            }
          />
        </FormControl>
      </Grid>
      <Grid item className={classes.center}>
        <RadioGroup
          aria-label="Role"
          name="Role"
          value={role}
          onChange={handleRoleChange}
        >
          <FormControlLabel
            value="Driver"
            control={<Radio />}
            label="I am a Driver"
          />
          <FormControlLabel
            value="Passanger"
            control={<Radio />}
            label="I am a Passenger"
          />
        </RadioGroup>
      </Grid>
      <Grid item className={classes.center}>
        <Button
          variant="contained"
          color="primary"
          disabled={disable}
          onClick={onSignUpClick}
        >
          Enter
        </Button>
      </Grid>
    </Grid>
  );
}

export default SignUpPage;
