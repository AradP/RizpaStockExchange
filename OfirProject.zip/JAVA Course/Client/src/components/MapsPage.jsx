import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Grid,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  Button,
  TextField,
  Typography,
} from "@material-ui/core";
import $ from "jquery";
import { useHistory, useParams } from "react-router-dom";

const useStyles = makeStyles((theme) => ({}));

function MapsPage() {
  const classes = useStyles();
  const { userName, role } = useParams();
  const history = useHistory();

  const [disableAddMap, setDisableAddMap] = React.useState(false);
  const [mapName, setMapName] = React.useState("");
  const [uploader, setUploader] = React.useState();
  const [moneyCharge, setMoneyCharge] = React.useState("");
  const [disableChargeMoney, setDisableChargeMoney] = React.useState(false);
  const [currentBalance, setCurrentBalance] = React.useState(0);
  const [balanceHistories, setBalanceHistories] = React.useState([]);
  const [maps, setMaps] = React.useState([]);

  const onChangeFile = (event) => {
    event.stopPropagation();
    event.preventDefault();
    var file = event.target.files[0];
    var formData = new FormData();
    formData.append("file", file);
    console.log(formData);
    console.log(file);
    $.ajax({
      method: "POST",
      data: formData,
      url: "/web_app_war/map?user=" + userName + "&mapName=" + mapName,
      processData: false, // Don't process the files
      contentType: false, // Set content type to false as jQuery will tell the server its a query string request
      timeout: 4000,
      error: function (e) {
        console.log(e);
      },
      success: function (data) {
        const arr = [];
        for (var i = 0; i < data.length; i++) {
          const map = data[i];
          arr.push({
            createUserName: map.userName,
            mapName: map.mapName,
            stops: map.stops.length,
            roads: map.paths.length,
            tripOffers: map.tripOffers.length,
            tripRequests: map.tripRequests.length,
          });
        }
        setMaps(arr);
      },
    });
  };

  const addMoney = () => {
    fetch("/web_app_war/money?user=" + userName + "&amount=" + moneyCharge, {
      method: "POST",
    })
      .then((response) => response.json())
      .then((data) => {
        setCurrentBalance(data.money);
        setBalanceHistories(data.balanceHistories);
      })
      .catch((error) => console.log("ERROR"));
  };

  const getUserData = async () => {
    fetch("/web_app_war/user?user=" + userName, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((data) => {
        setCurrentBalance(data.money);
        setBalanceHistories(data.balanceHistories);
      })
      .catch((error) => console.log("ERROR"));

    fetch("/web_app_war/map", {
      method: "GET",
    })
      .then((response) => response.json())
      .then((data) => {
        const arr = [];
        console.log(data);
        for (var i = 0; i < data.length; i++) {
          const map = data[i];
          arr.push({
            createUserName: map.userName,
            mapName: map.mapName,
            stops: map.stops.length,
            roads: map.paths.length,
            tripOffers: map.tripOffers.length,
            tripRequests: map.tripRequests.length,
          });
        }
        setMaps(arr);
      })
      .catch((error) => console.log("ERROR"));
  };

  React.useEffect(() => {
    setDisableAddMap(mapName === "");
  }, [mapName]);

  React.useEffect(() => {
    setDisableChargeMoney(moneyCharge === "");
  }, [moneyCharge]);

  React.useEffect(() => {
    getUserData();
  }, []);

  function goToMap(mapName) {
    history.push(`/mapDetail/${mapName}/${role}/${userName}`);
  }

  return (
    <Grid
      container
      style={{ justifyContent: "center", display: "flex", margin: "30px" }}
    >
      <Grid
        item
        xs={12}
        style={{
          display: "flex",
          justifyContent: "center",
          marginTop: "30px",
          marginBottom: "50px",
        }}
      >
        <Typography variant="h3">Account Manager for {userName}</Typography>
      </Grid>

      <Grid
        container
        spacing={2}
        style={{
          display: "flex",
          marginBottom: "15px",
        }}
      >
        <Grid item xs={3}>
          <TextField
            value={mapName}
            onChange={(event) => {
              setMapName(event.target.value);
            }}
            label="Map Name"
            style={{ width: "100%" }}
          />
        </Grid>
        <Grid item xs={2}>
          <Button
            variant="contained"
            color="primary"
            disabled={disableAddMap}
            onClick={() => {
              uploader.click();
            }}
          >
            Add Map
          </Button>
        </Grid>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ justifyContent: "center", display: "flex" }}
      >
        <Grid item xs={12}>
          <TableContainer component={Paper}>
            <Table className={classes.table} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>User Name</TableCell>
                  <TableCell align="left">Map Name</TableCell>
                  <TableCell align="right">Stops</TableCell>
                  <TableCell align="right">Roads</TableCell>
                  <TableCell align="right">Trip Offers</TableCell>
                  <TableCell align="right">Trip Requests</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {maps.map((row) => (
                  <TableRow
                    key={row.mapName}
                    onClick={() => {
                      goToMap(row.mapName);
                    }}
                  >
                    <TableCell align="left">{row.createUserName}</TableCell>
                    <TableCell align="left">{row.mapName}</TableCell>
                    <TableCell align="right">{row.stops}</TableCell>
                    <TableCell align="right">{row.roads}</TableCell>
                    <TableCell align="right">{row.tripOffers}</TableCell>
                    <TableCell align="right">{row.tripRequests}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </Grid>
      <input
        ref={(ref) => setUploader(ref)}
        type="file"
        style={{ display: "none" }}
        onChange={onChangeFile}
      />
      <Grid
        container
        spacing={2}
        style={{
          display: "flex",
          marginBottom: "15px",
        }}
      >
        <Grid item xs={12} style={{ display: "flex", marginTop: "30px" }}>
          <Typography variant="h5">Money Manager</Typography>
        </Grid>

        <Grid item xs={3}>
          <TextField
            value={moneyCharge}
            onChange={(event) => {
              setMoneyCharge(event.target.value);
            }}
            label="Charge Amount"
            style={{ width: "100%" }}
          />
        </Grid>
        <Grid item xs={2}>
          <Button
            variant="contained"
            color="primary"
            disabled={disableChargeMoney}
            onClick={addMoney}
          >
            Charge
          </Button>
        </Grid>
        <Grid item xs>
          <Typography>Balance - {currentBalance}</Typography>
        </Grid>
        <Grid
          item
          xs={12}
          style={{
            display: "flex",
          }}
        >
          <TableContainer component={Paper}>
            <Table className={classes.table} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Action ID</TableCell>
                  <TableCell align="left">Action Type</TableCell>
                  <TableCell align="left">Date</TableCell>
                  <TableCell align="right">Amount</TableCell>
                  <TableCell align="right">Balance Before</TableCell>
                  <TableCell align="right">Balance After</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {balanceHistories.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell component="th" scope="row">
                      {row.id}
                    </TableCell>
                    <TableCell align="left">{row.type}</TableCell>
                    <TableCell align="left">{row.date}</TableCell>
                    <TableCell align="right">{row.amount}</TableCell>
                    <TableCell align="right">{row.before}</TableCell>
                    <TableCell align="right">{row.after}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </Grid>
    </Grid>
  );
}

export default MapsPage;
