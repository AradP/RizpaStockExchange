import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Grid,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  Typography,
  Button,
} from "@material-ui/core";
import { useParams, useHistory } from "react-router-dom";
import TripOfferPopup from "../components/TripOfferPopup";
import TripRequestPopup from "../components/TripRequestPopup";
import MatchPopup from "../components/MatchPopup";

const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(1),
  },
  back: {},
  alignAll: {
    display: "block",
  },
  center: {
    display: "flex",
    justifyContent: "center",
    margin: "20px",
  },
  button: {
    display: "block",
    marginTop: theme.spacing(2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
}));

function MapDetailPage() {
  const classes = useStyles();
  const { mapName, role, userName } = useParams();
  const history = useHistory();
  const [map, setMap] = React.useState(null);
  const [circles, setCircles] = React.useState([]);
  const [stations, setStations] = React.useState([]);
  const [stationNames, setStationNames] = React.useState([]);
  const [paths, setPaths] = React.useState([]);
  const [openDialog, setDialogOpen] = React.useState(false);
  const [matchPopup, setMatchPopup] = React.useState(false);
  const [tripOffers, setTripOffers] = React.useState([]);
  const [tripRequests, setTripRequests] = React.useState([]);

  function addNewOffer() {
    handleOpenDialog();
  }

  function handleOpenDialog() {
    setDialogOpen(true);
  }
  function addNewRequest() {
    handleOpenDialog();
  }

  const getMap = async () => {
    fetch("/web_app_war/map?map=" + mapName, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((data) => {
        setMap(data);
        setTripOffers(data.tripOffers);
        setTripRequests(data.tripRequests);
        console.log(data);
      })
      .catch((error) => console.log("ERROR"));
  };

  const mapDrawing =
    map !== null ? (
      <svg
        width={map.mapBoundries.width * 50}
        height={map.mapBoundries.height * 50}
      >
        <rect
          width={map.mapBoundries.width * 50}
          height={map.mapBoundries.height * 50}
          style={{ fill: "lightblue", strokeWidth: 1, stroke: "rgb(0,0,0)" }}
        />

        {circles}

        {stations}

        {stationNames}

        {paths}
      </svg>
    ) : null;

  const showRoute = (route) => {
    const pathElements = [];
    for (let i = 0; i < route.length - 1; i++) {
      paths.forEach((element) => {
        let newEl;
        if (element.props.id === route[i] + "->" + route[i + 1]) {
          newEl = React.cloneElement(element, {
            style: { stroke: "yellow", strokeWidth: 4 },
          });
        } else {
          newEl = React.cloneElement(element, {
            style: { stroke: "blue", strokeWidth: 1 },
          });
        }
        pathElements.push(newEl);
      });
    }
    setPaths(pathElements);
  };

  const showStops = (destName, originName) => {
    const stopsElements = [];
    for (let i = 0; i < stations.length; i++) {
      let newEl;
      if (
        stations[i].props.id === originName ||
        stations[i].props.id === destName
      ) {
        newEl = React.cloneElement(stations[i], {
          fill: "yellow",
        });
      } else {
        newEl = React.cloneElement(stations[i], {
          fill: "red",
        });
      }
      stopsElements.push(newEl);
    }
    setStations(stopsElements);
  };

  React.useEffect(() => {
    getMap();
  }, []);

  React.useEffect(() => {
    if (map !== null) {
      const arrCircles = [];
      for (let i = 0; i < map.mapBoundries.height; i++) {
        for (let j = 0; j < map.mapBoundries.width; j++) {
          arrCircles.push(
            <circle
              cx={30 + j * 50}
              cy={20 + i * 50}
              r="2"
              stroke="black"
              strokeWidth="1"
              fill="black"
            />
          );
        }
      }
      setCircles(arrCircles);

      const arrNames = [];
      const arrStops = [];
      for (let stop = 0; stop < map.stops.length; stop++) {
        const currentStop = map.stops[stop];
        arrNames.push(
          <text
            x={25 + (currentStop.x - 1) * 50}
            y={10 + (currentStop.y - 1) * 50}
            fill="purple"
            fontSize="20px"
          >
            {currentStop.name}
          </text>
        );
        arrStops.push(
          <circle
            id={currentStop.name}
            cx={30 + (currentStop.x - 1) * 50}
            cy={20 + (currentStop.y - 1) * 50}
            r="7"
            stroke="black"
            strokeWidth="1"
            fill="red"
          />
        );
      }
      setStations(arrStops);
      setStationNames(arrNames);

      const arrPaths = [];
      for (let path = 0; path < map.paths.length; path++) {
        const currentPath = map.paths[path];
        const originStop = map.stops.find(
          (stop) => currentPath.from === stop.name
        );
        const destStop = map.stops.find((stop) => currentPath.to === stop.name);
        arrPaths.push(
          <line
            id={originStop.name + "->" + destStop.name}
            x1={30 + (originStop.x - 1) * 50}
            y1={20 + (originStop.y - 1) * 50}
            x2={30 + (destStop.x - 1) * 50}
            y2={20 + (destStop.y - 1) * 50}
            style={{ stroke: "blue", strokeWidth: 1 }}
          />
        );
      }
      setPaths(arrPaths);
    }
  }, [map]);

  return (
    <div style={{ width: "100%" }}>
      <Button
        style={{ margin: "20px", width: "100%" }}
        variant="contained"
        color="primary"
        disableElevation
        onClick={() => {
          history.push("/maps/" + userName + "/" + role);
        }}
      >
        BACK TO MAPS SCREEN
      </Button>
      <Typography variant="h3" style={{ textAlign: "center" }}>
        Map: {mapName}
      </Typography>
      <div style={{ display: "flex", justifyContent: "center" }}>
        {mapDrawing}
      </div>
      {role === "Driver" ? (
        <div style={{ margin: "20px" }}>
          <Button
            style={{ width: "100%" }}
            variant="contained"
            color="primary"
            disableElevation
            onClick={() => addNewOffer()}
          >
            Add Trip Offer
          </Button>
          <TripOfferPopup
            openDialog={openDialog}
            setOpenDialog={() => setDialogOpen(!openDialog)}
            stationNames={map === null ? [] : map.stops}
            setTripOffers={setTripOffers}
            mapName={mapName}
          ></TripOfferPopup>
        </div>
      ) : (
        <div style={{ margin: "20px" }}>
          <Button
            style={{ width: "100%" }}
            variant="contained"
            color="primary"
            disableElevation
            onClick={() => addNewRequest()}
          >
            Add Trip Request
          </Button>
          <TripRequestPopup
            openDialog={openDialog}
            setOpenDialog={() => setDialogOpen(!openDialog)}
            stationNames={map === null ? [] : map.stops}
            setTripRequests={setTripRequests}
            mapName={mapName}
          ></TripRequestPopup>
        </div>
      )}
      <Grid container style={{ flexWrap: "nowrap" }}>
        <Grid container style={{ margin: "10px" }}>
          <Grid item xs={12}>
            <Typography variant="h5" style={{ textAlign: "center" }}>
              Trip Offers
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <TableContainer component={Paper}>
              <Table className={classes.table} aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>Driver Name</TableCell>
                    <TableCell align="left">Capacity</TableCell>
                    <TableCell align="right">PPK</TableCell>
                    <TableCell align="right">Hour Start</TableCell>
                    <TableCell align="right">Minute Start</TableCell>
                    <TableCell align="right">Recurrences</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {tripOffers.length
                    ? tripOffers.map((row) => (
                        <TableRow
                          key={row.id}
                          onClick={() => {
                            showRoute(row.route.stopsList);
                          }}
                        >
                          <TableCell align="left">{row.owner}</TableCell>
                          <TableCell align="left">{row.capacity}</TableCell>
                          <TableCell align="right">{row.ppk}</TableCell>
                          <TableCell align="right">
                            {row.scheduling.hourStart}
                          </TableCell>
                          <TableCell align="right">
                            {row.scheduling.minuteStart}
                          </TableCell>
                          <TableCell align="right">
                            {row.scheduling.recurrences}
                          </TableCell>
                        </TableRow>
                      ))
                    : null}
                </TableBody>
              </Table>
            </TableContainer>
          </Grid>
        </Grid>{" "}
        <Grid container style={{ margin: "10px" }}>
          <Grid item xs={12}>
            <Typography variant="h5" style={{ textAlign: "center" }}>
              Trip Requests
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <TableContainer component={Paper}>
              <Table className={classes.table} aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell align="left">Origin Stop</TableCell>
                    <TableCell align="right">Destination Stop</TableCell>
                    <TableCell align="right">Exit or Arrival</TableCell>
                    <TableCell align="right">Hour</TableCell>
                    <TableCell align="right">Minute</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {tripRequests.map((row) => (
                    <TableRow
                      key={row.id}
                      onClick={() => {
                        showStops(row.destinationStopName, row.originStopName);
                      }}
                    >
                      <TableCell align="left">{row.name}</TableCell>
                      <TableCell align="left">{row.originStopName}</TableCell>
                      <TableCell align="right">
                        {row.destinationStopName}
                      </TableCell>
                      <TableCell align="right">
                        {row.isOut ? "Exit" : "Arrival"}
                      </TableCell>
                      <TableCell align="right">{row.tripHour}</TableCell>
                      <TableCell align="right">{row.tripMinute}</TableCell>
                      <TableCell>
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={() => setMatchPopup(true)}
                        >
                          Match
                        </Button>
                        <MatchPopup
                          openDialog={matchPopup}
                          setOpenDialog={(val) => {
                            setMatchPopup(val);
                          }}
                          requestId={row.id}
                        ></MatchPopup>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Grid>{" "}
        </Grid>
      </Grid>
    </div>
  );
}

export default MapDetailPage;
