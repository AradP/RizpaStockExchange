package models;

public class TripRequest {

    private static int requestID = 1;
    private int id;
    private String name;
    private Stop originStop;
    private Stop destinationStop;
    private int tripHour;
    private int tripMinute;
    private boolean isExit;

    public TripRequest(String name, Stop originStop, Stop destinationStop, int tripHour, int tripMinute, boolean isExit) {
        this.id = requestID++;
        this.name = name;
        this.originStop = originStop;
        this.destinationStop = destinationStop;
        this.tripHour = tripHour;
        this.tripMinute = tripMinute;
        this.isExit = isExit;
    }

    public int getId() { return id; }

    public String getName() { return name; }

    public Stop getOriginStop() { return originStop; }

    public Stop getDestinationStop() { return destinationStop; }

    public int getTripHour() { return tripHour; }

    public int getTripMinute() { return tripMinute; }

    public boolean getIsExit() { return isExit; }
}
