package models;

import java.util.ArrayList;
import java.util.List;

public class Route {

    private List<String> stopsList = new ArrayList<>();
//  Calculated members
    private List<Integer> timeList;

    public Route(String stopsString) {
        for (String s : stopsString.split(",")) {
            this.stopsList.add(s.trim());
        }
    }

    public List<Integer> getTimeList() {
        return timeList;
    }

    public void setTimeList(List<Integer> timeList) {
        this.timeList = timeList;
    }

    public List<String> getStops() {
        return this.stopsList;
    }

    @Override
    public String toString() {
        return String.join(", ", this.stopsList);
    }
}
