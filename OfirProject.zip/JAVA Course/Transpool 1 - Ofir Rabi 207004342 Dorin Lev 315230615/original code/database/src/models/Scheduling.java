package models;

public class Scheduling {

    private int hourStart;
    private int minuteStart;
    private int dayStart;
    private String recurrences;

    public Scheduling(int hourStart, int minuteStart, int dayStart, String recurrences) {
        this.hourStart = hourStart;
        this.minuteStart = minuteStart;
        this.dayStart = dayStart;
        this.recurrences = recurrences;
    }

    public int getMinuteStart() { return minuteStart; }

    public int getHourStart() {
        return hourStart;
    }

    public int getDayStart() {
        return dayStart;
    }

    public String getRecurrences() {
        return recurrences;
    }
}
