package models;

public class Match {
    private int offerId;
    private int requestId;
    private int cost;
    private int minutesTaken;
    private int averageFuelConsumption;
    private String originStop;
    private String destinationStop;

    public Match(int offerId, int requestId, int cost, int minutesTaken, int averageFuelConsumption, String originStop, String destinationStop) {
        this.offerId = offerId;
        this.requestId = requestId;
        this.cost = cost;
        this.minutesTaken = minutesTaken;
        this.averageFuelConsumption = averageFuelConsumption;
        this.originStop = originStop;
        this.destinationStop = destinationStop;
    }

    public String getOriginStop() {
        return originStop;
    }

    public String getDestinationStop() {
        return destinationStop;
    }

    public int getOfferId() {
        return offerId;
    }

    public int getRequestId() {
        return requestId;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getMinutesTaken() {
        return minutesTaken;
    }

    public void setMinutesTaken(int minutesTaken) {
        this.minutesTaken = minutesTaken;
    }

    public int getAverageFuelConsumption() {
        return averageFuelConsumption;
    }

    public void setAverageFuelConsumption(int averageFuelConsumption) {
        this.averageFuelConsumption = averageFuelConsumption;
    }
}
