package db;

import models.Path;
import java.util.ArrayList;
import java.util.List;

public class Paths {
    private static List<Path> paths = new ArrayList<>();

    public static List<Path> getPaths() {
        return Paths.paths;
    }

    public static void addPaths(List<Path> newPaths) {
        paths.addAll(newPaths);
    }

    public static Path getPath(String from, String to) {
        return Paths.getPaths().stream().filter(path -> (path.getFrom().equals(from) && path.getTo().equals(to)) ||
                (!path.isOneWay() && path.getFrom().equals(to) && path.getTo().equals(from)))
                .findFirst().orElse(null);
    }

    public static void clearPaths() {
        Paths.paths = new ArrayList<>();
    }
}
