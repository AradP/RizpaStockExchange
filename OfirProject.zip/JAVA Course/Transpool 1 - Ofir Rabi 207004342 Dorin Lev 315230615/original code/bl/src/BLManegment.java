import controllers.*;
import db.*;
import exceptions.general.NoNameEnteredException;
import exceptions.general.WrongHourException;
import exceptions.general.WrongMinutesException;
import exceptions.matches.MatchDoesntExistException;
import exceptions.tripRequests.StopDoesntExistException;
import exceptions.xml.*;
import models.*;
import org.xml.sax.SAXException;
import validations.TripRequestsValidations;
import xml.XmlLoader;
import xml.XmlValidations;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BLManegment {

    public static int currentDay = 1;

    private static List<Match> offersAvailableForCurrentMatch = new ArrayList<>();

    public static void loadXML(String pathName) throws IncorrectFileTypeException, ParserConfigurationException, SAXException, IOException,
                                                       XPathExpressionException, WrongMapBoundriesException, NotUniqueNameException, NotUniqueLocationException,
                                                       NotInMapBoundriesException, UnexistingStopException, NegativeNumberException, WrongHourException,
                                                       WrongRecurrencesException, WrongRouteException, NumberFormatException {
        XmlLoader xmlLoader = new XmlLoader(pathName);

        MapBoundriesDB.clearMapBoundries();
        Stops.clearStops();
        Paths.clearPaths();
        TripOffers.clearOffers();
        TripRequests.clearRequests();
        Matches.clearMatches();

        MapBoundries mapBoundries = xmlLoader.parseMapBoundries();
        XmlValidations.checkMapBoundries(mapBoundries);
        MapBoundriesController.setMapBoundries(mapBoundries);

        List<Stop> stops = xmlLoader.parseStops();
        XmlValidations.checkStops(stops);
        StopsController.addStops(stops);

        List<Path> paths = xmlLoader.parsePaths();
        XmlValidations.checkPaths(paths);
        PathsController.addPaths(paths);

        List<TripOffer> tripOffers = xmlLoader.parseTripOffers();
        XmlValidations.checkTripOffers(tripOffers);
        TripOffersController.addTripOffers(tripOffers);
    }

    public static List<String> getAllStopsNames() {
        return StopsController.getStopsNames();
    }

    public static List<String> getAllTripOffers() {
        return TripOffersController.getAllTripOffers();
    }

    public static List<String> getAllTripRequests() {
        return TripRequestsController.getAllTripRequests(true);
    }

    public static void addNewTripOffer(String name,String path,int hour, String recurrences,int ppk, int passengers) throws NegativeNumberException, WrongRecurrencesException, WrongHourException, WrongRouteException {
        TripOffersController.addNewTripOffer(name, path, hour, recurrences, ppk, passengers);
    }
    public static void addNewTripRequest(String name, String originStopName, String destinationStopName, int tripHour, int tripMinute, boolean isExit) throws NoNameEnteredException, WrongMinutesException, StopDoesntExistException, WrongHourException {
        originStopName = originStopName.trim();
        destinationStopName = destinationStopName.trim();
        TripRequestsValidations.checkNewTripRequest(name, originStopName, destinationStopName, tripHour, tripMinute);
        TripRequestsController.addTripRequest(new TripRequest(name,
                                                    StopsController.getStopByName(originStopName),
                                                    StopsController.getStopByName(destinationStopName),
                                                    tripHour,
                                                    tripMinute,
                                                    isExit));
    }

    public static List<String> getAllUnmatchedRequests() {
        return TripRequestsController.getAllTripRequests(false);
    }

    public static List<String> findMatches(int requestId, int maxOptions) {
        List<String> offers = new ArrayList<>();
        String currentMatch;

        offersAvailableForCurrentMatch = MatchesController.findMatches(requestId, maxOptions);

        for(Match match : offersAvailableForCurrentMatch) {
            TripRequest currentRequest = TripRequests.getRequest(match.getRequestId());
            currentMatch = "";

            currentMatch += "**********************\n";

            currentMatch += "Offer number " + match.getOfferId() + "\n";
            currentMatch += "The offer owner is " + TripOffers.getOffer(match.getOfferId()).getOwner() + "\n";
            currentMatch += "The cost is " + match.getCost() + "\n";

            if (currentRequest.getIsExit()) {
                currentMatch += "We will arrive to " + currentRequest.getDestinationStop().getName() + " at " +
                        timeFormatToMatch(currentRequest.getTripHour(), currentRequest.getTripMinute(), match.getMinutesTaken()) + "\n";
            } else {
                currentMatch += "We will start from " + currentRequest.getOriginStop().getName() + " at " +
                        timeFormatToMatch(currentRequest.getTripHour(), currentRequest.getTripMinute(), -1 * match.getMinutesTaken()) + "\n";
            }

            currentMatch += "Fuel consumption is " + match.getAverageFuelConsumption() + "\n";
            currentMatch += "**********************\n";

            offers.add(currentMatch);
        }

        return offers;
    }

    private static String timeFormatToMatch(int hourStart, int minuteStart, int addMinutes) {
        return getTimeFormat((hourStart + addMinutes / 60), (minuteStart + addMinutes % 60));
    }

    private static String getTimeFormat(int hours, int minutes) {
        return ("00" + hours).substring(String.valueOf(hours).length()) + ":" +
                ("00" + minutes).substring(String.valueOf(minutes).length());
    }

    public static void match(int requestId, int offerId) throws MatchDoesntExistException {

        boolean isValid = false;
        Match chosen = null;

        for(Match match : offersAvailableForCurrentMatch) {
            if(match.getOfferId() == offerId){
                isValid = true;
                chosen = match;
                break;
            }
        }

        if(isValid) {
            Matches.addMatch(chosen);
        } else throw new MatchDoesntExistException();
    }
}
