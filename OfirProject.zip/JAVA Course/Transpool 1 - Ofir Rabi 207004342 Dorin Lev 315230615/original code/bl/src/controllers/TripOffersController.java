package controllers;

import db.*;
import exceptions.general.WrongHourException;
import exceptions.xml.NegativeNumberException;
import exceptions.xml.WrongRecurrencesException;
import exceptions.xml.WrongRouteException;
import models.*;
import xml.XmlValidations;
import java.util.ArrayList;
import java.util.List;

public class TripOffersController {

    public static void addTripOffers(List<TripOffer> newTripOffers) {

//      Calculate extra details
        for (TripOffer tripOffer : newTripOffers) {
            tripOffer.setTripValue(calculateAllRouteValue(tripOffer));
            tripOffer.getRoute().setTimeList(getTimeListForRoute(tripOffer));
            tripOffer.setTripTimeInMinutes(getFinishMinutes(tripOffer));
            tripOffer.setAverageFuelConsumption(getAverageFuelConsumption(tripOffer));
        }

        TripOffers.addTripOffers(newTripOffers);
    }

    private static int getAverageFuelConsumption(TripOffer tripOffer) {
        int fuelConsumption = 0;

        for (int i = 0; i < tripOffer.getRoute().getStops().size() - 1; i++) {
            fuelConsumption += Paths.getPath(tripOffer.getRoute().getStops().get(i), tripOffer.getRoute().getStops().get(i+1)).getFuelConsumption();
        }

        return fuelConsumption / (tripOffer.getRoute().getStops().size());
    }

    private static List<Integer> getTimeListForRoute(TripOffer tripOffer) {
        List<Integer> timeList = new ArrayList<>();
        timeList.add(0);
        for (int i = 1; i < tripOffer.getRoute().getStops().size(); i++) {
            timeList.add(timeList.get(i-1) +
                         Paths.getPath(tripOffer.getRoute().getStops().get(i-1), tripOffer.getRoute().getStops().get(i)).getTimeInMinutes());
        }
        return timeList;
    }

    private static int getFinishMinutes(TripOffer tripOffer) {
        return tripOffer.getRoute().getTimeList().get(tripOffer.getRoute().getTimeList().size() - 1);
    }

    public static List<String> getAllTripOffers() {
        List<String> offers = new ArrayList<>();
        String currentOffer;

        for (TripOffer trip: TripOffers.getTripOffers()) {
            currentOffer = "";

            currentOffer += "************************\n";
            currentOffer += "Trip number " + trip.getId() + ":\n";
            currentOffer += "Hi, I am " + trip.getOwner() + ".\n";
            currentOffer += "This is the route of my trip, by order:\n" + trip.getRoute().toString() + ".\n";
            currentOffer += "The full cost of my route is " + trip.getTripValue() + ".\n";
            currentOffer += "I am going to start my trip at " + getStartTime(trip)
                    + " and finish it by " + getFinishTime(trip) + ".\n";
            currentOffer += "I can take maximum " + trip.getCapacity() + " passenger";
            if(trip.getCapacity() == 1) {
                currentOffer += ".\n";
            } else currentOffer += "s.\n";

            currentOffer += "These are the capacities in each stop, by route order:\n";
            for (String stopName : trip.getRoute().getStops()) {
                currentOffer += stopName + ": " + getOfferCapacityInStop(trip, stopName) + ".\n";
            }


            if(Matches.getAllByOfferId(trip.getId()).size() > 0) {
                List<Match> allMatches = Matches.getAllByOfferId(trip.getId());
                currentOffer += "Our passengers details: \n";
                for(Match match : allMatches) {
                    currentOffer += "Request number " + match.getRequestId() + "\n";
                }
                for(String stop : trip.getRoute().getStops()) {
                    for(Match match : allMatches) {
                        if(stop.equals(TripRequests.getRequest(match.getRequestId()).getOriginStop().getName())) {
                            currentOffer += stop + ": " + TripRequests.getRequest(match.getRequestId()).getName() + " Goes up\n";
                        }
                        if(stop.equals(TripRequests.getRequest(match.getRequestId()).getDestinationStop().getName())) {
                            currentOffer += stop + ": " + TripRequests.getRequest(match.getRequestId()).getName() + " Goes down\n";
                        }
                    }
                }

            } else currentOffer += "There are no passengers yet\n";
            currentOffer += "By the way, the average fuel consumption of the trip is "
                    + trip.getAverageFuelConsumption() + " Kilometers per fuel liter.\n";

            currentOffer += "************************\n";

            offers.add(currentOffer);
        }

        return offers;
    }

    private static String getFinishTime(TripOffer trip) {
        int hour = trip.getScheduling().getHourStart() + trip.getTripTimeInMinutes() / 60;
        int minutes = trip.getScheduling().getMinuteStart() + trip.getTripTimeInMinutes() % 60;
        return getTimeFormat(hour, minutes);
    }

    private static String getStartTime(TripOffer trip) {
        return getTimeFormat(trip.getScheduling().getHourStart(), trip.getScheduling().getMinuteStart());
    }

    private static String getTimeFormat(int hours, int minutes) {
        return ("00" + hours).substring(String.valueOf(hours).length()) + ":" +
                ("00" + minutes).substring(String.valueOf(minutes).length());
    }

    private static int calculateAllRouteValue(TripOffer trip) {
        int kilometers = 0;

        for (int i = 0; i < trip.getRoute().getStops().size() - 1; i++) {
            kilometers += Paths.getPath(trip.getRoute().getStops().get(i), trip.getRoute().getStops().get(i + 1)).getLength();
        }

        return kilometers * trip.getPpk();
    }

    public static void addNewTripOffer(String name,String path,int hour, String recurrences,int ppk, int capacity) throws NegativeNumberException, WrongRecurrencesException, WrongHourException, WrongRouteException {

        List<TripOffer> tripOffers  = new ArrayList<>();
        TripOffer tripOffer;
        Route route = new Route(path);

        // TODO change day start to the system count
        Scheduling scheduling = new Scheduling(hour, 0,1,recurrences);

        tripOffer = new TripOffer(name,
                                  capacity,
                                  ppk,
                                  route,
                                  scheduling);

        tripOffers.add(tripOffer);

        XmlValidations.checkTripOffers(tripOffers);
        addTripOffers(tripOffers);
    }

    public static int getOfferCapacityInStop(TripOffer offer, String originStop) {
        List<Match> offerMatches = Matches.getAllByOfferId(offer.getId());
        int capacity = offer.getCapacity();
        int indexOfNewMatch = offer.getRoute().getStops().indexOf(originStop);

        for(Match match : offerMatches) {
            if (offer.getRoute().getStops().indexOf(match.getOriginStop()) <= indexOfNewMatch &&
                offer.getRoute().getStops().indexOf(match.getDestinationStop()) > indexOfNewMatch) {
                capacity--;
            }
        }

        return  capacity;
    }
}
