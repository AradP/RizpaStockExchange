package controllers;

import db.Matches;
import db.TripOffers;
import db.TripRequests;
import models.Match;
import models.TripRequest;
import java.util.ArrayList;
import java.util.List;

public class TripRequestsController {

    public static List<String> getAllTripRequests(boolean toLoadMatched){

        List<String> tripRequests = new ArrayList<>();
        String currentRequestText;
        Match currentMatch = null;

        List<TripRequest> requestsToDisplay;
        if (toLoadMatched) {
            requestsToDisplay = TripRequests.getTripRequests();
        } else {
            requestsToDisplay = MatchesController.getAllUnmatchedRequests();
        }

        for (TripRequest currentRequest: requestsToDisplay) {
            currentRequestText = "";

            currentRequestText += "************************\n";

            currentRequestText += "Details of trip request " + currentRequest.getId() + "\n";
            currentRequestText += "Owner: " + currentRequest.getName() + "\n";
            currentRequestText += "From stop " + currentRequest.getOriginStop().getName() + " to stop " +  currentRequest.getDestinationStop().getName() + "\n";
            if(currentRequest.getIsExit()) {
                currentRequestText += "Leaves at ";
            } else {
                currentRequestText += "Arrives at ";
            }
            currentRequestText += getTimeFormat(currentRequest.getTripHour(), currentRequest.getTripMinute()) + "\n";

            if(Matches.getAllByRequestId(currentRequest.getId()).size() > 0) {
                currentMatch = Matches.getAllByRequestId(currentRequest.getId()).get(0);
            }

            if(currentMatch != null) {
                currentRequestText += "Match details: \n";
                currentRequestText += "Offer number " + TripOffers.getOffer(currentMatch.getRequestId()).getId() + "\n" +
                        "The offer owner is " + TripOffers.getOffer(currentMatch.getOfferId()).getOwner() + "\n" +
                        "The cost is " + currentMatch.getCost() + "\n";//"Arrival time is " + timeFormatToMatch(currentMatch.getInformation().getFinishTime() + "\n" +

                if (currentRequest.getIsExit()) {
                    currentRequestText += "We will arrive at " +
                            timeFormatToMatch(currentRequest.getTripHour(), currentRequest.getTripMinute(), currentMatch.getMinutesTaken()) + "\n";
                } else {
                    currentRequestText += "We will start at " +
                            timeFormatToMatch(currentRequest.getTripHour(), currentRequest.getTripMinute(), -1 * currentMatch.getMinutesTaken()) + "\n";
                }

                currentRequestText += "Fuel consumption is " + currentMatch.getAverageFuelConsumption() + "\n";
            }

            currentRequestText += "************************\n";

            tripRequests.add(currentRequestText);

        }

        return tripRequests;
    }

    private static String timeFormatToMatch(int hourStart, int minuteStart, int addMinutes) {
        return getTimeFormat((hourStart + addMinutes / 60) ,(minuteStart + addMinutes % 60));
    }

    private static String getTimeFormat(int hours, int minutes) {
        return ("00" + hours).substring(String.valueOf(hours).length()) + ":" +
                ("00" + minutes).substring(String.valueOf(minutes).length());
    }

    public static void addTripRequest(TripRequest tripRequest) {
        TripRequests.addTripRequest(tripRequest);
    }
}
