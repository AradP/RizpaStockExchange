package controllers;

import db.Matches;
import db.Paths;
import db.TripOffers;
import db.TripRequests;
import models.*;
import java.util.ArrayList;
import java.util.List;

public class MatchesController {
    public static List<TripRequest> getAllUnmatchedRequests() {
        List<TripRequest> unmatchedRequests = new ArrayList<>();

        for(TripRequest request : TripRequests.getTripRequests()) {
            if(Matches.getAllByRequestId(request.getId()).size() == 0) {
                unmatchedRequests.add(request);
            }
        }

        return unmatchedRequests;
    }

    public static List<Match> findMatches(int requestId, int maxOptions) {
        List<Match> offers = new ArrayList<>();
        TripRequest request = TripRequests.getRequest(requestId);

        if(request == null) return offers;

        for (TripOffer offer : TripOffers.getTripOffers()) {
            if(offers.size() <= maxOptions) {
                if (isCapacityLeft(offer, request) &&
                        (offer.getRoute().getStops().indexOf(request.getOriginStop().getName()) != -1 && offer.getRoute().getStops().indexOf(request.getDestinationStop().getName()) != -1) &&
                        (offer.getRoute().getStops().indexOf(request.getOriginStop().getName()) < offer.getRoute().getStops().indexOf(request.getDestinationStop().getName()))) {

                    if (request.getIsExit()) {
                        if (isInTheSameTime(offer, request.getOriginStop().getName(), request.getTripHour(), request.getTripMinute())) {
                            offers.add(getNewMatch(offer, request));
                        }
                    } else {
                        if (isInTheSameTime(offer, request.getDestinationStop().getName(), request.getTripHour(), request.getTripMinute())){
                            offers.add(getNewMatch(offer, request));
                        }
                    }
                }
            } else break;
        }
        return offers;
    }

    private static boolean isCapacityLeft(TripOffer offer, TripRequest request) {
        return TripOffersController.getOfferCapacityInStop(offer, request.getOriginStop().getName()) > 0;
    }

    private static boolean isInTheSameTime(TripOffer offer, String stopName, int hour, int minute) {

        int stopIndex = offer.getRoute().getStops().indexOf(stopName);
        int offerHourAtStop = offer.getScheduling().getHourStart() + offer.getRoute().getTimeList().get(stopIndex) / 60;
        int offerMinuteAtStop = offer.getScheduling().getMinuteStart() + offer.getRoute().getTimeList().get(stopIndex) % 60;

        return offerHourAtStop == hour && offerMinuteAtStop == minute;

    }

    private static Match getNewMatch(TripOffer offer, TripRequest request) {
        int cost = 0;
        int minuteTaken = 0;
        int averageFuelConsumption = 0;
        int stopsCounter = 0;

        for (int i = offer.getRoute().getStops().indexOf(request.getOriginStop().getName());
             i < offer.getRoute().getStops().indexOf(request.getDestinationStop().getName());
             i++) {
            Path currentPath = Paths.getPath(offer.getRoute().getStops().get(i), offer.getRoute().getStops().get(i + 1));
            cost += currentPath.getLength();
            minuteTaken += currentPath.getTimeInMinutes();
            averageFuelConsumption += currentPath.getFuelConsumption();
            stopsCounter++;
        }

        averageFuelConsumption /= stopsCounter;
        cost *= offer.getPpk();

        return new Match(offer.getId(), request.getId(), cost, minuteTaken, averageFuelConsumption, request.getOriginStop().getName(), request.getDestinationStop().getName());
    }
}
