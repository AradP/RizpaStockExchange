package general;

public class Constants {
    public static final String RECURRENCE_ONE_TIME = "OneTime";
    public static final String RECURRENCE_DAILY = "Daily";
    public static final String RECURRENCE_DOUBLE_DAILY = "BiDaily";
    public static final String RECURRENCE_WEEKLY = "Weekly";
    public static final String RECURRENCE_MONTHLY = "Monthly";
}
