package exceptions.tripRequests;

public class StopDoesntExistException extends Exception {
    public StopDoesntExistException(String message){ super(message); }
}
