package exceptions.xml;

public class NotUniqueNameException extends Exception {
    public NotUniqueNameException() {
        super();
    }
    public NotUniqueNameException(String message) {
        super(message);
    }
}
