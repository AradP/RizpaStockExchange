package exceptions.xml;

public class WrongRecurrencesException extends Exception {
    public WrongRecurrencesException() {
        super();
    }
    public WrongRecurrencesException(String message) {
        super(message);
    }
}
