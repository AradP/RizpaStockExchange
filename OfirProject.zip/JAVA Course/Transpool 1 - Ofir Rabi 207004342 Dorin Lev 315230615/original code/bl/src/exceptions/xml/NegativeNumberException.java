package exceptions.xml;

public class NegativeNumberException extends Exception {
    public NegativeNumberException() {
        super();
    }
    public NegativeNumberException(String message) {
        super(message);
    }
}
