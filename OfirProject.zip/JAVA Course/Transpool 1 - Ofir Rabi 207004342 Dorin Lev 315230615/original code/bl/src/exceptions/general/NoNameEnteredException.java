package exceptions.general;

public class NoNameEnteredException extends Exception{
    public NoNameEnteredException() {super();}
}
