package exceptions.general;

public class WrongMinutesException extends Exception {
    public WrongMinutesException(){super();}
    public WrongMinutesException(String message){super(message);}
}
