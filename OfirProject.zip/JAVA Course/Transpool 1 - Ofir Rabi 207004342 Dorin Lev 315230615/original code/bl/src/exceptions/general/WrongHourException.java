package exceptions.general;

public class WrongHourException extends Exception {
    public WrongHourException() {
        super();
    }
    public WrongHourException(String message) {
        super(message);
    }
}
