package controllers;

import db.*;
import exceptions.general.WrongHourException;
import exceptions.xml.NegativeNumberException;
import exceptions.xml.WrongRecurrencesException;
import exceptions.xml.WrongRouteException;
import general.Constants;
//import javafx.util.Pair;
import models.*;
import xml.XmlValidations;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;

public class TripOffersController {

    public static List<TripOfferWithStop> getCurrentTripOffersWithStop(int currentMinute, String stopName) {
        List<TripOfferWithStop> trips = new ArrayList<>();
        Stop currentStop;
        for(TripOffer tripOffer : TripOffers.getTripOffers()) {
            switch (tripOffer.getScheduling().getRecurrences()) {
                case Constants.RECURRENCE_ONE_TIME:
                    if (currentMinute / (60 * 24) + 1 == tripOffer.getScheduling().getDayStart()) {
                        currentStop = getStopByMinutes(currentMinute % (60 * 24), tripOffer);
                        if(currentStop != null && currentStop.getName().equals(stopName)) {
                            trips.add(new TripOfferWithStop(tripOffer, currentStop));
                        }
                    }
                    break;

                case Constants.RECURRENCE_DAILY:
                    currentStop = getStopByMinutes(currentMinute % (60 * 24), tripOffer);
                    if(currentStop != null && currentStop.getName().equals(stopName)) {
                        trips.add(new TripOfferWithStop(tripOffer, currentStop));
                    }
                    break;

                case Constants.RECURRENCE_DOUBLE_DAILY:
                    if((currentMinute / (60 * 24) + 1 - tripOffer.getScheduling().getDayStart()) % 2 == 0) {
                        currentStop = getStopByMinutes(currentMinute % (60 * 24), tripOffer);
                        if(currentStop != null && currentStop.getName().equals(stopName)) {
                            trips.add(new TripOfferWithStop(tripOffer, currentStop));
                        }
                    }
                    break;

                case Constants.RECURRENCE_WEEKLY:
                    if((currentMinute / (60 * 24) + 1 - tripOffer.getScheduling().getDayStart()) % 7 == 0) {
                        currentStop = getStopByMinutes(currentMinute % (60 * 24), tripOffer);
                        if(currentStop != null && currentStop.getName().equals(stopName)) {
                            trips.add(new TripOfferWithStop(tripOffer, currentStop));
                        }
                    }
                    break;

                case Constants.RECURRENCE_MONTHLY:
                    if((currentMinute / (60 * 24) + 1 - tripOffer.getScheduling().getDayStart()) % 30 == 0) {
                        currentStop = getStopByMinutes(currentMinute % (60 * 24), tripOffer);
                        if(currentStop != null && currentStop.getName().equals(stopName)) {
                            trips.add(new TripOfferWithStop(tripOffer, currentStop));
                        }
                    }
                    break;
            }
        }

        return trips;
    }

    public static Stop getStopByMinutes(int minuets, TripOffer tripOffer) {
        Stop stopToReturn = null;
        int startMinutes = tripOffer.getScheduling().getHourStart() * 60 + tripOffer.getScheduling().getMinuteStart();
        for (int i = 0; i < tripOffer.getRoute().getStops().size() - 1; i++) {
            if (minuets >= startMinutes)  {
                stopToReturn = Stops.getStop(tripOffer.getRoute().getStops().get(i));
                if (minuets > startMinutes && i == tripOffer.getRoute().getStops().size() - 2) {
                    stopToReturn = null;
                }
            }
            startMinutes += Paths.getPath(tripOffer.getRoute().getStops().get(i),
                                          tripOffer.getRoute().getStops().get(i + 1)).getTimeInMinutes();
        }



        return stopToReturn;
    }

    public static void addTripOffers(List<TripOffer> newTripOffers) {

//      Calculate extra details
//        for (TripOffer tripOffer : newTripOffers) {
//            tripOffer.setTripValue(calculateAllRouteValue(tripOffer));
//            tripOffer.getRoute().setTimeList(getTimeListForRoute(tripOffer));
//            tripOffer.setTripTimeInMinutes(getFinishMinutes(tripOffer));
//            tripOffer.setAverageFuelConsumption(getAverageFuelConsumption(tripOffer));
//        }

        TripOffers.addTripOffers(newTripOffers);
    }

    private static int getAverageFuelConsumption(TripOffer tripOffer) {
        int fuelConsumption = 0;

        for (int i = 0; i < tripOffer.getRoute().getStops().size() - 1; i++) {
            fuelConsumption += Paths.getPath(tripOffer.getRoute().getStops().get(i), tripOffer.getRoute().getStops().get(i+1)).getFuelConsumption();
        }

        return fuelConsumption / (tripOffer.getRoute().getStops().size());
    }

    private static List<Integer> getTimeListForRoute(TripOffer tripOffer) {
        List<Integer> timeList = new ArrayList<>();
        timeList.add(0);
        for (int i = 1; i < tripOffer.getRoute().getStops().size(); i++) {
            timeList.add(timeList.get(i-1) +
                         Paths.getPath(tripOffer.getRoute().getStops().get(i-1), tripOffer.getRoute().getStops().get(i)).getTimeInMinutes());
        }
        return timeList;
    }

//    private static int getFinishMinutes(TripOffer tripOffer) {
//        return tripOffer.getRoute().getTimeList().get(tripOffer.getRoute().getTimeList().size() - 1);
//    }

    public static List<String> getAllTripOffers() {
        List<String> offers = new ArrayList<>();
        String currentOffer;

        for (TripOffer trip: TripOffers.getTripOffers()) {
            currentOffer = "";

            currentOffer += "Trip number " + trip.getId() + " \n";
            currentOffer += "Hi, I am " + trip.getOwner() + ".\n";
            currentOffer += "This is the route of my trip, by order:\n" + trip.getRoute().toString() + ".\n";
            currentOffer += "I can take maximum " + trip.getCapacity() + " passenger";
            if(trip.getCapacity() == 1) {
                currentOffer += ".\n";
            } else currentOffer += "s.\n";

            offers.add(currentOffer);
        }

        return offers;
    }

    public static List<String> getTripOfferById(int id) {
        List<String> offers = new ArrayList<>();
        String currentOffer;
        TripOffer tripOffer = TripOffers.getOffer(id);

            currentOffer = "";

            currentOffer += "Trip Offer ID " + tripOffer.getId() + " \n";
            currentOffer += "Hi, I am " + tripOffer.getOwner() + ".\n";
            currentOffer += "This is the route of my trip, by order:\n" + tripOffer.getRoute().toString() + ".\n";
            currentOffer += "The cost of my trip is \n" + TripOffers.calculateTripOfferCost(tripOffer)+ ".\n";
//            currentOffer += "This is the average fuel consumption of my trip \n" + + ".\n";




            currentOffer += "I can take maximum " + tripOffer.getCapacity() + " passenger";
            if(tripOffer.getCapacity() == 1) {
                currentOffer += ".\n";
            } else currentOffer += "s.\n";

            offers.add(currentOffer);

        return offers;
    }


//    private static String getFinishTime(TripOffer trip) {
//        int hour = trip.getScheduling().getHourStart() + trip.getTripTimeInMinutes() / 60;
//        int minutes = trip.getScheduling().getMinuteStart() + trip.getTripTimeInMinutes() % 60;
//        return getTimeFormat(hour, minutes);
//    }

    private static String getStartTime(TripOffer trip) {
        return getTimeFormat(trip.getScheduling().getHourStart(), trip.getScheduling().getMinuteStart());
    }

    private static String getTimeFormat(int hours, int minutes) {
        return ("00" + hours).substring(String.valueOf(hours).length()) + ":" +
                ("00" + minutes).substring(String.valueOf(minutes).length());
    }

    public static void addTripOffer(TripOffer newOffer, String mapName) {
        Transpool transpool1 = Transpools.getTranspools().stream().filter(transpool -> (transpool.getMapName().equals(mapName))).findAny().orElse(null);
        transpool1.addTripOffer(newOffer);
    }

    private static int calculateAllRouteValue(TripOffer trip) {
        int kilometers = 0;

        for (int i = 0; i < trip.getRoute().getStops().size() - 1; i++) {
            kilometers += Paths.getPath(trip.getRoute().getStops().get(i), trip.getRoute().getStops().get(i + 1)).getLength();
        }

        return kilometers * trip.getPpk();
    }

    public static void addNewTripOffer(String name,String path,int hour, String recurrences,int ppk, int capacity) throws NegativeNumberException, WrongRecurrencesException, WrongHourException, WrongRouteException {

        List<TripOffer> tripOffers  = new ArrayList<>();
        TripOffer tripOffer;
        Route route = new Route(path);

        // TODO change day start to the system count
        Scheduling scheduling = new Scheduling(hour, 0,1,recurrences);

        tripOffer = new TripOffer(name,
                                  capacity,
                                  ppk,
                                  route,
                                  scheduling);

        tripOffers.add(tripOffer);

        XmlValidations.checkTripOffers(tripOffers);
        addTripOffers(tripOffers);
    }

    public static int getOfferCapacityInStop(TripOffer offer, String originStop) {
        List<Match> offerMatches = Matches.getAllByOfferId(offer.getId());
        int capacity = offer.getCapacity();
        int indexOfNewMatch = offer.getRoute().getStops().indexOf(originStop);

        for(Match match : offerMatches) {
            if (offer.getRoute().getStops().indexOf(match.getOriginStop()) <= indexOfNewMatch &&
                offer.getRoute().getStops().indexOf(match.getDestinationStop()) > indexOfNewMatch) {
                capacity--;
            }
        }

        return  capacity;
    }

    public static int getMinutesInStop(TripOffer tripOffer, String stopName) {
        int minutesCount = tripOffer.getScheduling().getHourStart() * 60 + tripOffer.getScheduling().getMinuteStart();
        for (int i = 0; i < tripOffer.getRoute().getStops().size() - 1; i++) {
            if(tripOffer.getRoute().getStops().get(i).equals(stopName)) {
                break;
            }
            Path path = Paths.getPath(tripOffer.getRoute().getStops().get(i), tripOffer.getRoute().getStops().get(i + 1));
            minutesCount += path.getTimeInMinutes();
        }

        return minutesCount;
    }
}
