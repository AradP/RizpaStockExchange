package controllers;

import models.MapBoundries;
import models.Transpool;

public class MapBoundriesController {
    public static boolean inMapBoundries(Transpool transpool, int x, int y){
        return ((x >= 0 && x <= transpool.getMapBoundries().getWidth()) && (y >= 0 && y <= transpool.getMapBoundries().getHeight()));
    }
//    public static void setMapBoundries(MapBoundries mapBoundries) {
//        MapBoundriesDB.setMapBoundries(mapBoundries);
//    }
//    public static MapBoundries getMapBoundries() {
//        return MapBoundriesDB.getMapBoundries();
//    }
}
