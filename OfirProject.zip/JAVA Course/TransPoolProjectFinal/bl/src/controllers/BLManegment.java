package controllers;

import db.*;
import exceptions.general.NoNameEnteredException;
import exceptions.general.WrongHourException;
import exceptions.general.WrongMinutesException;
import exceptions.matches.MatchDoesntExistException;
import exceptions.tripRequests.StopDoesntExistException;
import exceptions.xml.*;
import general.Constants;
//import javafx.util.Pair;
import models.*;
import org.xml.sax.SAXException;
import validations.TripRequestsValidations;
import xml.XmlLoader;
import xml.XmlValidations;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.SplittableRandom;
import java.util.stream.Collectors;

public class BLManegment {

    private static int currentMinute = 0;
    private static int tripOfferToShow = 0;
    private static int tripRequestToShow = 0;
    private static int selectedMatch = 0;

    private  static  List<List<Match>> allMatchList;

    public static boolean addUser(String name, String role){
        return UsersController.addUser(name, role);
    }

    public static User getUserByName(String name){
        return UsersController.getUserByName(name);
    }

    public static User changeMoney(int amount, String userName, String type) {
        User user = UsersController.getUserByName(userName);
        user.addMoney(amount, type);
        return user;
    }

    public static void changeCurrentMinute(int addingMinutes) {
        if (currentMinute + addingMinutes >= 0) {
            currentMinute += addingMinutes;
        }
    }

    public static int getCurrentMinute() {
        return currentMinute;
    }

    public static List<Transpool> getAllTranspools () {
        return Transpools.getTranspools();
    }

    public static List<Transpool> loadXML(InputStream pathName, String mapName, String userName) throws IncorrectFileTypeException, ParserConfigurationException, SAXException, IOException,
                                                       XPathExpressionException, WrongMapBoundriesException, NotUniqueNameException, NotUniqueLocationException,
                                                       NotInMapBoundriesException, UnexistingStopException, NegativeNumberException, WrongHourException,
                                                       WrongRecurrencesException, WrongRouteException, NumberFormatException {
        XmlLoader xmlLoader = new XmlLoader(pathName);

        Transpool transpool = new Transpool(userName, mapName);

        System.out.println("Created new transpool");

        MapBoundries mapBoundries = xmlLoader.parseMapBoundries();
        XmlValidations.checkMapBoundries(mapBoundries);
        transpool.setMapBoundries(mapBoundries);

        System.out.println("Set map boundries");

        List<Stop> stops = xmlLoader.parseStops();
        XmlValidations.checkStops(stops, transpool);
        transpool.setStops(stops);

        System.out.println("Set stops");

        List<Path> paths = xmlLoader.parsePaths();
        XmlValidations.checkPaths(paths, transpool);
        transpool.setPaths(paths);

        System.out.println("Set paths");

        Transpools.add(transpool);

        return Transpools.getTranspools();
    }

//    public static MapBoundries getMapBoundries () {
//        return MapBoundriesController.getMapBoundries();
//    }

    public static List<Stop> getAllStops() {
        return StopsController.getAllStops();
    }

    public static List<Path> getAllPaths() {
        return PathsController.getAllPaths();
    }

    public static Stop getStopByName(String name) {
        return StopsController.getStopByName(name);
    }

    public static List<String> getAllTripRequestsToShow() {
        return TripRequestsController.getAllTripRequests();
    }


    public static List<TripRequest> addTripRequest(String mapName, String name, String originStopName, String destinationStopName, String tripDay,
                                      String tripHour, String tripMinute, boolean isOutTime)
            throws NumberFormatException {
        int day = -1, hour = -1, minute = -1;

        try {
            day = Integer.parseInt(tripDay);
        } catch (Exception e) {
            throw new NumberFormatException("Day should be an integer number");
        }

        if (day < 1) {
            throw new NumberFormatException("Day should be above 0");
        }

        try {
            hour = Integer.parseInt(tripHour);
        } catch (Exception e) {
            throw new NumberFormatException("Hour should be an integer number");
        }

        if (hour < 0 || hour > 23) {
            throw new NumberFormatException("Hour should be between 0-23");
        }

        try {
            minute = Integer.parseInt(tripMinute);
        } catch (Exception e) {
            throw new NumberFormatException("Minute should be an integer number");
        }

        if (minute % 5 != 0 || minute < 0 || minute > 55) {
            throw new NumberFormatException("Minute should be between 0-55 and divided by 5");
        }

        TripRequestsController.addTripRequest(new TripRequest(name, originStopName, destinationStopName, day,
                hour, minute, isOutTime), mapName);

        return Transpools.getTranspools().stream().filter(transpool -> (transpool.getMapName().equals(mapName))).findAny().orElse(null).getTripRequests();

    }

    public static List<TripOffer> addTripOffer(String mapName, String name, List<String> path, String tripDay,
                                    String tripHour, String tripMinute, String recurrence,
                                    String tripPpk, String tripCapacity)
            throws NumberFormatException {
        int day, hour, minute, ppk, capacity;

        try {
            day = Integer.parseInt(tripDay);
        } catch (Exception e) {
            throw new NumberFormatException("Day should be an integer number");
        }

        if (day < 1) {
            throw new NumberFormatException("Day should be above 0");
        }

        try {
            hour = Integer.parseInt(tripHour);
        } catch (Exception e) {
            throw new NumberFormatException("Hour should be an integer number");
        }

        if (hour < 0 || hour > 23) {
            throw new NumberFormatException("Hour should be between 0-23");
        }

        try {
            minute = Integer.parseInt(tripMinute);
        } catch (Exception e) {
            throw new NumberFormatException("Minute should be an integer number");
        }

        if (minute % 5 != 0 || minute < 0 || minute > 55) {
            throw new NumberFormatException("Minute should be between 0-55 and divided by 5");
        }

        try {
            capacity = Integer.parseInt(tripCapacity);
        } catch (Exception e) {
            throw new NumberFormatException("Capacity should be an integer number");
        }

        if (capacity < 0) {
            throw new NumberFormatException("Capacity should be positive");
        }

        try {
            ppk = Integer.parseInt(tripPpk);
        } catch (Exception e) {
            throw new NumberFormatException("PPK should be an integer number");
        }

        if (ppk < 0) {
            throw new NumberFormatException("PPK should be positive");
        }

        TripOffersController.addTripOffer(new TripOffer(name, capacity, ppk, new Route(path),
                new Scheduling(hour, minute, day, recurrence)), mapName);

        return Transpools.getTranspools().stream().filter(transpool -> (transpool.getMapName().equals(mapName))).findAny().orElse(null).getTripOffers();
    }

    public static List<TripOfferWithStop> getCurrentTripOffersWithStop(String stopName) {
        return TripOffersController.getCurrentTripOffersWithStop(currentMinute, stopName);
    }

    public static List<String> getUnmatchedRequests() {
        return TripRequestsController.getUnmatchedRequests();
    }

    public static List<List<Match>> getMatchedByRequestId(int requestId, int amount) {
        allMatchList = new ArrayList<>();
        TripRequest tripRequest = TripRequests.getRequest(requestId);

        List<List<Integer>> allPossiblePaths = MatchesController.getAllPaths(Stops.getStop(tripRequest.getOriginStopName()).getId(),
                Stops.getStop(tripRequest.getDestinationStopName()).getId());

        for (List<Integer> possiblePath : allPossiblePaths) {

            List<String> stringListStops = new ArrayList<>();
            for (Integer stop : possiblePath) {
                stringListStops.add(Stops.getStop(stop).getName());
            }

            getTripByPossiblePath(stringListStops, new ArrayList<>(), tripRequest, 0, possiblePath.size());

        }

        removeUnpossibleMatchs(tripRequest);

        if(amount <= allMatchList.size()) {
            return allMatchList.subList(0, amount);
        }
        return allMatchList;
    }

    private static void removeUnpossibleMatchs(TripRequest tripRequest) {

        int tripRequestMinutes = tripRequest.getTripDay() * 24 * 60 + tripRequest.getTripHour() * 60 + tripRequest.getTripMinute();
        List<List<Match>> newMatchList = new ArrayList<>();

        if (tripRequest.getIsOut()) {

            for (List<Match> matchList : allMatchList) {

                boolean isValid = true;

                TripOffer tripOffer = TripOffers.getOffer(matchList.get(0).getOfferId());
                int minuetsToCompare = TripOffersController.getMinutesInStop(tripOffer, matchList.get(0).getOriginStop());
                if(!(minuetsToCompare / 60 == tripRequest.getTripHour() && minuetsToCompare % 60 == tripRequest.getTripMinute())) {
                    isValid = false;
                }
                else if (tripRequest.getTripDay() < tripOffer.getScheduling().getDayStart()) {
                    isValid = false;
                }
                if(!isReaccuranceGood(tripOffer, tripRequest.getTripDay())) {
                    isValid = false;
                }

                for(Match match : matchList) {
                    if(!isEnoughSpaceInCarByStop(tripOffer, match.getOriginStop())) {
                        isValid = false;
                    }
                }

                // TODO check according to reaccurance and minutes

                if(isValid) {
                    newMatchList.add(matchList);
                }
            }
        } else {
            for (List<Match> matchList : allMatchList) {
                boolean isValid = true;
                TripOffer tripOffer = TripOffers.getOffer(matchList.get(matchList.size() - 1).getOfferId());
                int minutesArrived = TripOffersController.getMinutesInStop(tripOffer, matchList.get(matchList.size() - 1).getDestinationStop());

                if(minutesArrived != tripRequest.getTripHour() * 60 + tripRequest.getTripMinute()) {
                    isValid = false;
                }
                if(tripOffer.getScheduling().getDayStart() > tripRequest.getTripDay()) {
                    isValid = false;
                }
                if(!isReaccuranceGood(tripOffer, tripRequest.getTripDay())) {
                    isValid = false;
                }

                for(Match match : matchList) {
                    if(!isEnoughSpaceInCarByStop(tripOffer, match.getOriginStop())) {
                        isValid = false;
                    }
                }

                if(isValid) {
                    newMatchList.add(matchList);
                }
            }
        }

        allMatchList = newMatchList;
    }

    private static boolean isEnoughSpaceInCarByStop(TripOffer tripOffer, String stopName) {
        int passengersInStop = (int) Matches.getAllByOfferId(tripOffer.getId()).stream().filter(match -> match.getOriginStop().equals(stopName)).count();
        return tripOffer.getCapacity() > passengersInStop;
    }

    private static boolean isReaccuranceGood (TripOffer tripOffer, int tripReqDay){

        switch (tripOffer.getScheduling().getRecurrences()) {
            case Constants.RECURRENCE_ONE_TIME:
                return tripOffer.getScheduling().getDayStart() == tripReqDay;

            case Constants.RECURRENCE_DAILY:
                return tripOffer.getScheduling().getDayStart() <= tripReqDay;

            case Constants.RECURRENCE_DOUBLE_DAILY:
                return tripOffer.getScheduling().getDayStart() <= tripReqDay && (tripReqDay - tripOffer.getScheduling().getDayStart()) % 2 == 0;

            case Constants.RECURRENCE_WEEKLY:
                return tripOffer.getScheduling().getDayStart() <= tripReqDay && (tripReqDay - tripOffer.getScheduling().getDayStart()) % 7 == 0;

            case Constants.RECURRENCE_MONTHLY:
                return tripOffer.getScheduling().getDayStart() <= tripReqDay && (tripReqDay - tripOffer.getScheduling().getDayStart()) % 30 == 0;
        }

        return false;
    }

    private static void getTripByPossiblePath(List<String> possiblePath, List<Match> matchList, TripRequest tripRequest, int start, int end) {

        int cost = 0,minutesTaken = 0,fuel = 0;

        if(matchList.size() > 0) {
            if(matchList.get(matchList.size() - 1).getDestinationStop().equals(tripRequest.getDestinationStopName())) {
                allMatchList.add(new ArrayList<>(matchList));
                return;
            }
        }

        if(end - start < 2) {
            return;
        }

        List<TripOffer> tripOffers = TripOffers.getBySubRoute(possiblePath.subList(start, end));

        for (TripOffer tripOffer : tripOffers) {
            List<Match> tempMatchList = new ArrayList<>(matchList);
            cost = Paths.getPath(possiblePath.get(start),possiblePath.get(end - 1)).getLength() * tripOffer.getPpk();
            minutesTaken = Paths.getPath(possiblePath.get(start),possiblePath.get(end - 1)).getTimeInMinutes();
            fuel = Paths.getPath(possiblePath.get(start),possiblePath.get(end - 1)).getFuelConsumption();

            tempMatchList.add(new Match(tripOffer.getId(), tripRequest.getId(), cost, minutesTaken, fuel, possiblePath.get(start), possiblePath.get(end - 1)));

            getTripByPossiblePath(possiblePath, tempMatchList, tripRequest, start + end - 1, end);
        }

        getTripByPossiblePath(possiblePath, matchList, tripRequest, start, end - 1);
    }

    public static void match(int selectedMatchIndex) {
        for(Match match : allMatchList.get(selectedMatchIndex)) {
            Matches.addMatch(match);
        }

        selectedMatch = selectedMatchIndex;
    }

    public static TripRequest getTripRequest(int id) {
        return TripRequests.getRequest(id);
    }

    public static TripOffer getTripOffer(int id) {
        return TripOffers.getOffer(id);
    }

    public static TripOffer getTripOfferToShow() {
        return TripOffers.getOffer(tripOfferToShow);
    }

    public static TripRequest getTripRequestToShow() {
        return TripRequests.getRequest(tripRequestToShow);
    }

    public static void setTripRequestToShow(int tripRequestToShow) {
        BLManegment.tripRequestToShow = tripRequestToShow;
    }

    public static void setTripOfferToShow(int tripOfferToShow) {
        BLManegment.tripOfferToShow = tripOfferToShow;
    }

    public static int calculateTripOfferCost (TripOffer tripOffer){
        int cost = 0;

        for (int i = 0; i < tripOffer.getRoute().getStops().size() - 1; i++){
            Path path = Paths.getPath(tripOffer.getRoute().getStops().get(i),tripOffer.getRoute().getStops().get(i+1));
            cost += path.getLength() * tripOffer.getPpk();
        }

        return cost;
    }

    public static int calculateTripOfferFuel (TripOffer tripOffer){
        int fuel = 0;
        int count = 0;

        for (int i = 0; i < tripOffer.getRoute().getStops().size() - 1; i++){
            Path path = Paths.getPath(tripOffer.getRoute().getStops().get(i),tripOffer.getRoute().getStops().get(i+1));
            fuel += path.getFuelConsumption();
            count++;
        }

        return fuel / count;
    }

    public static String getArrivalTimeForTripOffer(TripOffer tripOffer){

        int i = TripOffersController.getMinutesInStop(tripOffer,tripOffer.getRoute().getStops().get(tripOffer.getRoute().getStops().size()-1));

        int time = tripOffer.getScheduling().getHourStart() * 60 + tripOffer.getScheduling().getMinuteStart() + i;

        return time / 60 + ":" + time % 60;
    }

    public static String getReqTime(TripRequest tripRequest){

        if (tripRequest.getIsOut()){
            return "Exit time: " + tripRequest.getTripHour() + ":" +tripRequest.getTripMinute();
        } else {
            return "Arrival time: " + tripRequest.getTripHour() + ":" +tripRequest.getTripMinute();
        }
    }

    public static boolean isTripReqMatched(TripRequest tripRequest){
        if(Matches.getAllByRequestId(tripRequest.getId()).size() > 0){
            return true;
        }
        return false;
    }

    public static String getOffersDetailsForReq(TripRequest tripRequest){
        List<Match> tripMatches = Matches.getAllByRequestId(tripRequest.getId());
        String s = "";
        int cost = 0, fuel = 0;
        s += "Match details: \n";
        for (Match m : tripMatches){
            TripOffer  tripOffer = TripOffers.getOffer(m.getOfferId());
            s += "Trip offer ID " + tripOffer.getId() + "\n";
            s += "It's owner " + tripOffer.getOwner() + "\n";

            cost += calculateTripOfferCost(tripOffer);
            fuel += calculateTripOfferFuel(tripOffer);

        }

        TripOffer lastTripOffer = TripOffers.getOffer(tripMatches.get(tripMatches.size() - 1).getOfferId());
        int m  = TripOffersController.getMinutesInStop(lastTripOffer, tripMatches.get(tripMatches.size() - 1).getDestinationStop());

        s+= "The cost of the trip is " + cost + "\n" + "And the average fuel consumption is " + fuel / tripMatches.size() +
                "\nArrives at " + m / 60 + ":" + m % 60 ;
        return s;
    }

    public static String getStopsDetailsForTripOffer(TripOffer tripOffer) {
        List<Match> tripMatches = Matches.getAllByOfferId(tripOffer.getId());
        String s = "";
        if (tripMatches.size() > 0) {
            s += "Stops details: \n";
            for(String stopName : tripOffer.getRoute().getStops()) {
                s += stopName + " - \n";
                s += "Capacity: " + (tripOffer.getCapacity() - tripMatches.stream().filter(match -> match.getOriginStop().equals(stopName)).count())+ "\n";
                s += "Goes up : ";
                for(Match m : tripMatches.stream().filter(match -> match.getOriginStop().equals(stopName)).collect(Collectors.toList())) {
                    s += TripRequests.getRequest(m.getRequestId()).getName() + ", ";
                }
                s += "\nGoes down : ";
                for(Match m : tripMatches.stream().filter(match -> match.getDestinationStop().equals(stopName)).collect(Collectors.toList())) {
                    s += TripRequests.getRequest(m.getRequestId()).getName() + ", ";
                }
                s += "\n";
            }
        } else {
            s += "There are no passengers yet.\n";
        }

        return s;
    }

    public static void rateDriver(int stars, String description) {
        for(Match match : allMatchList.get(selectedMatch)) {
            TripOffers.getOffer(match.getOfferId()).addRating(stars);
            if(description.isEmpty() == false) {
                TripOffers.getOffer(match.getOfferId()).addRatingDesc(description);
            }
        }
    }

    public static String getDriverRatings(TripOffer tripOffer) {
        String s = "Rating details: \n";
        int avg = 0;
        for (int r : tripOffer.getRatings()) {
            avg += r;
        }

        if(tripOffer.getRatings().size() > 0) {
            avg /= tripOffer.getRatings().size();
            s += tripOffer.getRatings().size() + " rate you so far.\n";
            s += "The average rating is: " + avg + "\n";
            if (tripOffer.getRatingDescs().size() > 0) {
                s += "Here are the comments: \n";
                for(String rate : tripOffer.getRatingDescs()) {
                    s += "\"" + rate + "\"\n";
                }
            }
        } else {
            s += "No ratings.";
        }

        return s;
    }

    public static Transpool     getTranspool(String mapName) {
        return Transpools.getTranspools().stream().filter(transpool -> (transpool.getMapName().equals(mapName))).findAny().orElse(null);
    }
}
