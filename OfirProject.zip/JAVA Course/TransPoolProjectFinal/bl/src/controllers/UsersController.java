package controllers;

import models.User;

import java.util.ArrayList;

public class UsersController {

    public static boolean addUser(String name, String role){
        if (db.Users.getUserByName(name) == null){
            db.Users.addUser(name, role);
            return true;
        }
        return false;
    }

    public static ArrayList<User> getAllUsers(){
        return db.Users.getAllUsers();
    }

    public static User getUserByName(String name){
        return db.Users.getUserByName(name);
    }
}
