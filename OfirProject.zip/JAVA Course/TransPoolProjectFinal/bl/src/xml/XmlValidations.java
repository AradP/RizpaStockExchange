package xml;

import controllers.MapBoundriesController;
import controllers.StopsController;
import db.Paths;
import exceptions.general.WrongHourException;
import exceptions.xml.*;
import general.Constants;
import models.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class XmlValidations {
    public static void checkDocumentIsXML(String pathFile) throws IncorrectFileTypeException {
        if (!pathFile.endsWith(".xml")) {
            throw new IncorrectFileTypeException();
        }
    }

    public static void checkMapBoundries(MapBoundries mapBoundries) throws WrongMapBoundriesException {
        if (!(( mapBoundries.getHeight() >= 6 && mapBoundries.getHeight() <= 100 ) &&
                (mapBoundries.getWidth() >= 6 && mapBoundries.getWidth() <= 100))) {
            throw new WrongMapBoundriesException();
        }
    }

    public static void checkStops(List<Stop> stops, Transpool transpool) throws NotUniqueNameException, NotUniqueLocationException, NotInMapBoundriesException {
        String location;

        for (Stop checkedStop : stops) {

//          Check that the checked stop is in the map boundries
            if (MapBoundriesController.inMapBoundries(transpool, checkedStop.getX(),checkedStop.getY())) {

//              Check that the checked stop has a uniq name
                if (stops.stream().filter(stop -> (stop.getName().equals(checkedStop.getName()))).count() > 1) {
                    throw new NotUniqueNameException(checkedStop.getName());
                }

//              Check that the checked stop has a uniq location
                if (stops.stream().filter(stop -> (stop.getX() == checkedStop.getX() && stop.getY() == checkedStop.getY())).count() > 1) {
                    throw new NotUniqueLocationException(checkedStop.getName());
                }

            } else {
                location = "(" + checkedStop.getX() + "," + checkedStop.getY() + ")";
                throw new NotInMapBoundriesException(location);
            }

        }
    }

    public static void checkPaths(List<Path> paths, Transpool transpool) throws UnexistingStopException, NegativeNumberException {
//        for(Path path : paths) {
//
////          Check that the checked path is between valid stops
//            if(StopsController.getStopByName(path.getFrom()) == null ||
//               StopsController.getStopByName(path.getTo()) == null ||
//               path.getTo().equals(path.getFrom())) {
//                throw new UnexistingStopException(path.getFrom() + " and " + path.getTo());
//            }
//
//            if(path.getLength() <= 0) {
//                throw new NegativeNumberException("Length of path " + path.getFrom() + " to " + path.getTo()
//                                                  + "cannot be " + path.getLength());
//            }
//
//            if(path.getFuelConsumption() <= 0) {
//                throw new NegativeNumberException("Fuel consumption of path " + path.getFrom() + " to " + path.getTo() +
//                                                  " cannot be " + path.getFuelConsumption());
//            }
//
//            if(path.getSpeedLimit() <= 0) {
//                throw new NegativeNumberException("Speed limit of path " + path.getFrom() + " to " + path.getTo() +
//                                                  " cannot be " + path.getSpeedLimit());
//            }
//        }
    }

    public static void checkTripOffers(List<TripOffer> tripOffers) throws WrongHourException, WrongRecurrencesException, NegativeNumberException, WrongRouteException {

        for(TripOffer tripOffer : tripOffers) {

            if(!(tripOffer.getScheduling().getHourStart() >= 0 &&
               tripOffer.getScheduling().getHourStart() <= 23)) {
                throw new WrongHourException(String.valueOf(tripOffer.getScheduling().getHourStart()));
            }

            if(!tripOffer.getScheduling().getRecurrences().equals(Constants.RECURRENCE_DAILY) &&
               !tripOffer.getScheduling().getRecurrences().equals(Constants.RECURRENCE_DOUBLE_DAILY) &&
               !tripOffer.getScheduling().getRecurrences().equals(Constants.RECURRENCE_MONTHLY) &&
               !tripOffer.getScheduling().getRecurrences().equals(Constants.RECURRENCE_ONE_TIME) &&
               !tripOffer.getScheduling().getRecurrences().equals(Constants.RECURRENCE_WEEKLY)) {
                throw new WrongRecurrencesException(tripOffer.getScheduling().getRecurrences() + " of " + tripOffer.getOwner() + "'s trip");
            }

            if(tripOffer.getScheduling().getDayStart() <= 0) {
                throw new NegativeNumberException("The day start " + tripOffer.getScheduling().getDayStart()  + " of " +
                                                   tripOffer.getOwner() + "'s trip" + " must be positive" );
            }

            if (tripOffer.getCapacity() <= 0){
                throw new NegativeNumberException("Capacity " + tripOffer.getCapacity() + " of " +
                                                  tripOffer.getOwner() + "'s trip" + " must be positive");
            }

//          Check route has uniq stops
            Set uniqStops = new HashSet(tripOffer.getRoute().getStops());
            if(uniqStops.size() < tripOffer.getRoute().getStops().size()) {
                throw new WrongRouteException(String.valueOf(tripOffer.getRoute().getStops()));
            }
//          check root is between valid paths
            for(int i = 0; i < tripOffer.getRoute().getStops().size() - 1; i++) {
                if(Paths.getPath(tripOffer.getRoute().getStops().get(i), tripOffer.getRoute().getStops().get(i + 1)) == null) {
                    throw new WrongRouteException(String.valueOf(tripOffer.getRoute().getStops()));
                }
            }

        }

    }
}
