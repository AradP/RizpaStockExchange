package db;

import models.Transpool;

import java.util.ArrayList;
import java.util.List;

public class Transpools {
    private static List<Transpool> transpools = new ArrayList<>();

    public static List<Transpool> getTranspools() {
        return transpools;
    }

    public static void add(Transpool transpool) {
        Transpools.transpools.add(transpool);
    }
}
