package db;

import models.User;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class Users {

    private static ArrayList<User> users = new ArrayList<>();

    public static ArrayList<User> getAllUsers () {return Users.users;}

    public static User getUserByName (String name) {
        return Users.users.stream().filter(user -> (user.getUserName().equals(name))).findAny().orElse(null);
    }

    public static void addUser (String name, String role){
        Users.users.add(new User(name,role));
    }
}
