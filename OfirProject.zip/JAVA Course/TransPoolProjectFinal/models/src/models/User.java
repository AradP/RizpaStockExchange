package models;

import java.util.ArrayList;
import java.util.List;

public class User {

    private String userName;
    private String role;
    private int money;
    private List<BalanceHistory> balanceHistories;

    public User(String userName, String role) {
        this.userName = userName;
        this.role = role;
        this.money = 0;
        this.balanceHistories = new ArrayList<>();
        this.balanceHistories.add(new BalanceHistory("Charge", 0,0,0));
    }

    public int getMoney() {

        return money;
    }

    public void addMoney(int money, String type) {
        balanceHistories.add(new BalanceHistory(type, money,this.money,this.money + money));
        this.money += money;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
