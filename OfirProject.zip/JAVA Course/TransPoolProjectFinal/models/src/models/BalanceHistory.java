package models;

import java.util.Date;

public class BalanceHistory {
    private static int idCounter = 1;
    private String type;
    private Date date;
    private int amount;
    private int before;
    private int after;
    private int id;

    public BalanceHistory(String type, int amount, int before, int after) {
        this.type = type;
        this.date = new Date();
        this.amount = amount;
        this.before = before;
        this.after = after;
        this.id = idCounter++;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getBefore() {
        return before;
    }

    public void setBefore(int before) {
        this.before = before;
    }

    public int getAfter() {
        return after;
    }

    public void setAfter(int after) {
        this.after = after;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
