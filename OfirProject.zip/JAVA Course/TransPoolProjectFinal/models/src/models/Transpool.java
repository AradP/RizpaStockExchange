package models;

import java.util.ArrayList;
import java.util.List;

public class Transpool {
    private MapBoundries mapBoundries;
    private List<Stop> stops;
    private List<Path> paths;
    private String userName;
    private String mapName;
    private List<TripOffer> tripOffers;
    private List<TripRequest> tripRequests;

    public Transpool(String userName, String mapName) {
        this.stops = new ArrayList<>();
        this.paths = new ArrayList<>();
        this.tripOffers = new ArrayList<>();
        this.tripRequests = new ArrayList<>();
        this.userName = userName;
        this.mapName = mapName;
    }

    public MapBoundries getMapBoundries() {
        return mapBoundries;
    }

    public void setMapBoundries(MapBoundries mapBoundries) {
        this.mapBoundries = mapBoundries;
    }

    public List<Stop> getStops() {
        return stops;
    }

    public void setStops(List<Stop> stops) {
        this.stops = stops;
    }

    public List<Path> getPaths() {
        return paths;
    }

    public void setPaths(List<Path> paths) {
        this.paths = paths;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMapName() {
        return mapName;
    }

    public void setMapName(String mapName) {
        this.mapName = mapName;
    }

    public void addTripOffer(TripOffer tripOffer) {
        this.tripOffers.add(tripOffer);
    }
    public void addTripRequest(TripRequest tripRequest) {
        this.tripRequests.add(tripRequest);
    }


    public List<TripOffer> getTripOffers() {
        return tripOffers;
    }

    public List<TripRequest> getTripRequests() {
        return tripRequests;
    }
}
