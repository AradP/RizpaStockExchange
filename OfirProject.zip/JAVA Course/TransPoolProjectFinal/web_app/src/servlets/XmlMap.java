package servlets;

import com.google.gson.Gson;
import controllers.BLManegment;
import exceptions.general.WrongHourException;
import exceptions.xml.*;
import models.Transpool;
import org.xml.sax.SAXException;
import xml.XmlLoader;
import xml.XmlValidations;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.*;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

@WebServlet(name = "XmlMapServlet", urlPatterns = "/map")
@MultipartConfig(fileSizeThreshold = 1024 * 1024, maxFileSize = 1024 * 1024 * 5, maxRequestSize = 1024 * 1024 * 5 * 5)
public class XmlMap extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        String mapName = request.getParameter("mapName");
        String userName = request.getParameter("user");
        InputStream inputStreamXML = null;

        for (Part part : request.getParts()) {
            inputStreamXML = part.getInputStream();
        }

        try {
            List<Transpool> transpoolList = BLManegment.loadXML(inputStreamXML, mapName, userName);
            try (PrintWriter out = response.getWriter()) {
                Gson gson = new Gson();
                out.print(gson.toJson(transpoolList));
                out.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        String mapName = request.getParameter("map");
        if(mapName == null) {
            List<Transpool> transpoolList = BLManegment.getAllTranspools();

            try (PrintWriter out = response.getWriter()) {
                Gson gson = new Gson();
                out.print(gson.toJson(transpoolList));
                out.flush();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Transpool transpool = BLManegment.getTranspool(mapName);
            try (PrintWriter out = response.getWriter()) {
                Gson gson = new Gson();
                out.print(gson.toJson(transpool));
                out.flush();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private String readFromInputStream(InputStream inputStream) {
        return new Scanner(inputStream).useDelimiter("\\Z").next();
    }
}
