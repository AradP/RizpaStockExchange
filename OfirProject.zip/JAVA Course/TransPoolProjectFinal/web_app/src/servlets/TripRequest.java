package servlets;

import com.google.gson.Gson;
import controllers.BLManegment;
import exceptions.general.WrongHourException;
import exceptions.xml.*;
import models.Transpool;
import org.xml.sax.SAXException;
import xml.XmlLoader;
import xml.XmlValidations;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.*;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

@WebServlet(name = "TripRequestServlet", urlPatterns = "/tripRequest")
@MultipartConfig(fileSizeThreshold = 1024 * 1024, maxFileSize = 1024 * 1024 * 5, maxRequestSize = 1024 * 1024 * 5 * 5)
public class TripRequest extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");

        String mapName = readFromInputStream(request.getPart("mapName").getInputStream());
        String requesterName = readFromInputStream(request.getPart("name").getInputStream());
        String originStop = readFromInputStream(request.getPart("origin").getInputStream());
        String destStop = readFromInputStream(request.getPart("dest").getInputStream());
        String valueTime = readFromInputStream(request.getPart("valueTime").getInputStream());
        String hour = readFromInputStream(request.getPart("hour").getInputStream());
        String minutes = readFromInputStream(request.getPart("minutes").getInputStream());

//        public static void addTripRequest(String mapName, String name,
//        String originStopName, String destinationStopName, String tripDay,
//                String tripHour, String tripMinute, boolean isOutTime

        boolean isOutTime;
        if (valueTime.equals("exit")){
            isOutTime = true;
        } else {
            isOutTime = false;
        }

        List<models.TripRequest> tripRequests =
                BLManegment.addTripRequest(mapName, requesterName,
        originStop,destStop,"1", hour, minutes,isOutTime);

        try (PrintWriter out = response.getWriter()) {
            Gson gson = new Gson();
            out.print(gson.toJson(tripRequests));
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String readFromInputStream(InputStream inputStream) {
        return new Scanner(inputStream).useDelimiter("\\Z").next();
    }
}
