self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "422ddce42088367c10ad4d5771fe1980",
    "url": "/index.html"
  },
  {
    "revision": "cf39a15bac54ea01c7a2",
    "url": "/static/css/main.2ef1f548.chunk.css"
  },
  {
    "revision": "ee1a5ef6d3b6cacfbb08",
    "url": "/static/js/2.a32bf137.chunk.js"
  },
  {
    "revision": "ca962714ee3537eb863ad2954c33c63e",
    "url": "/static/js/2.a32bf137.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cf39a15bac54ea01c7a2",
    "url": "/static/js/main.80cd7764.chunk.js"
  },
  {
    "revision": "f988084e915f655d7c8a",
    "url": "/static/js/runtime-main.932c877e.js"
  }
]);