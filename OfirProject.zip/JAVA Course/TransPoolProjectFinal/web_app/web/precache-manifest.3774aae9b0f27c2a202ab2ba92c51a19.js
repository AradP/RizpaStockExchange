self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b0ab40219b67f4ae24af2688454dd3a7",
    "url": "/index.html"
  },
  {
    "revision": "73e401cb3bdfcb6eade9",
    "url": "/static/css/main.2ef1f548.chunk.css"
  },
  {
    "revision": "ee1a5ef6d3b6cacfbb08",
    "url": "/static/js/2.a32bf137.chunk.js"
  },
  {
    "revision": "ca962714ee3537eb863ad2954c33c63e",
    "url": "/static/js/2.a32bf137.chunk.js.LICENSE.txt"
  },
  {
    "revision": "73e401cb3bdfcb6eade9",
    "url": "/static/js/main.6c9e53b2.chunk.js"
  },
  {
    "revision": "f988084e915f655d7c8a",
    "url": "/static/js/runtime-main.932c877e.js"
  }
]);