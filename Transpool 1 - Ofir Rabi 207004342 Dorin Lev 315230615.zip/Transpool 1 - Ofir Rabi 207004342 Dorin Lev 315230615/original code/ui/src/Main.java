import exceptions.general.NoNameEnteredException;
import exceptions.general.WrongHourException;
import exceptions.general.WrongMinutesException;
import exceptions.matches.MatchDoesntExistException;
import exceptions.tripRequests.StopDoesntExistException;
import exceptions.xml.*;
import general.Constants;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static final Scanner myScanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Hello and Welcome to Transpool!");
        System.out.println("-------------------------------\n");
        loadXml();
        showMenu();
    }

    public static void loadXml() {
        boolean isLoaded = false;
        String path;

        System.out.println("Please enter the full file path of the xml file:");

        while (!isLoaded) {
            path = myScanner.nextLine();
            try {
                BLManegment.loadXML(path);
                isLoaded = true;
            } catch (NumberFormatException e) {
                System.out.println("Oops! the system supports only integer values");
            }
            catch (IncorrectFileTypeException e) {
                System.out.println("Oops! Please enter .xml file");
            } catch (ParserConfigurationException | SAXException | IOException | XPathExpressionException e) {
                System.out.println("Oops! We cant find the requested file");
            } catch (WrongMapBoundriesException e) {
                System.out.println("Wrong map boundries\nMake sure width and height are between 6 and 100");
            } catch (NotUniqueNameException e) {
                System.out.println("We have few stops with the same name");
                System.out.println("Stop " + e.getMessage() + " has already been declared" );
            } catch (NotUniqueLocationException e) {
                System.out.println("Stop " + e.getMessage() +  " has another stop in the same location");
            } catch (NotInMapBoundriesException e) {
                System.out.println("The location " + e.getMessage() + " is stop out of map boundries");
            } catch (UnexistingStopException e) {
                System.out.println("Path between " + e.getMessage() + " does not exist");
            } catch (NegativeNumberException e) {
                if (e.getMessage().isEmpty()){
                    System.out.println("Unrecognized negative input");
                } else {
                    System.out.println(e.getMessage());
                }
            } catch (WrongHourException e) {
                System.out.println("Hour " + e.getMessage() + " is not between 0-23");
            } catch (WrongRecurrencesException e) {
                System.out.println("Recurrence " + e.getMessage() + " does not exist in the system");
            } catch (WrongRouteException e) {
                System.out.println("Route " + e.getMessage() + " is not valid");
            }

            if (!isLoaded) {
                System.out.println("Please try again:");
            } else {
                System.out.println("Great! The system is ready.\n");
            }
        }
    }

    public static int getInteger(String textToGet) {
        boolean isSuccess = false;
        int result = 0;

        System.out.println(textToGet);

        while(!isSuccess) {
            try {
                result = Integer.parseInt(myScanner.nextLine());
                isSuccess = true;
            } catch (Exception e) {
                System.out.println("It's an invalid number, please try again:");
            }
        }

        return result;
    }

    public static void showMenu() {
        int userChoice = -1;

        while (userChoice != Constants.CHOICE_EXIT) {

            System.out.println("Choose one of the following options:\n" +
                    Constants.CHOICE_REQUEST_TRIP + " - Request new trip\n" +
                    Constants.CHOICE_SHOW_ALL_OFFERS + " - Show all trip offers\n" +
                    Constants.CHOICE_SHOW_ALL_REQUESTS + " - Show all trip requests\n" +
                    Constants.CHOICE_MATCH + " - find matching trip\n" +
                    Constants.CHOICE_NEW_TRIP_OFFER + " - add new trip offer\n" +
                    Constants.CHOICE_EXIT + " - Exit Program\n" +
                    Constants.CHOICE_RESTART + " - Restart Program");

            userChoice = getInteger("Your choice is:");

            switch (userChoice) {
                case Constants.CHOICE_REQUEST_TRIP:
                    createNewTripRequest();
                    break;
                case Constants.CHOICE_SHOW_ALL_OFFERS:
                    showAllOffers();
                    break;
                case Constants.CHOICE_SHOW_ALL_REQUESTS:
                    showAllRequests();
                    break;
                case Constants.CHOICE_MATCH:
                    findMatchings();
                    break;
                case Constants.CHOICE_NEW_TRIP_OFFER:
                    createNewTripOffer();
                    break;
                case Constants.CHOICE_EXIT:
                    exitTranspool();
                    break;
                case Constants.CHOICE_RESTART:
                    restart();
                    break;
            }

        }
    }

    public static void restart() {
        loadXml();
    }

    public static void exitTranspool() {
        System.out.println("Bye! see you later :)");
        System.exit(0);
    }

    public static void createNewTripRequest() {

        String name, from, to, time;
        int hour = 0, minute = 0, isExit = 0;
        boolean isAdded = false, isTimeCorrect = false, isExitCorrect = false, isExitBoolean;

        System.out.println("What is your name?:");
        name = myScanner.nextLine();

        System.out.println("Hi " + name + ", These are all the stops in the system:");
        for(String stop : BLManegment.getAllStopsNames()) {
            System.out.println(stop + ",");
        }

        System.out.println("What is your origin stop? write the specific stop name, the system is case sensitive:");
        from = myScanner.nextLine();

        System.out.println("What is your destination stop? write the specific stop name, the system is case sensitive:");
        to = myScanner.nextLine();

        System.out.println("Do you want to enter you exit or arrival time ? \nPress 1 for exit or 2 for arrival");

        while (!isExitCorrect){
            isExit = getInteger("Please enter 1 for exit or 2 for arrival:");
            if (isExit == 1 || isExit == 2){
                isExitCorrect = true;
            }
        }
        
        if (isExit == 1) {
            isExitBoolean = true;
            System.out.println("When do you want to go? write in format HH:MM");
        } else {
            isExitBoolean = false;
            System.out.println("When do you want to arrive? write in format HH:MM");
        }

        while (!isTimeCorrect){
            time = myScanner.nextLine();
           try {
               hour = Integer.parseInt(time.split(":")[0]);
               minute = Integer.parseInt(time.split(":")[1]);
               isTimeCorrect = true;
           } catch (Exception e) {
               System.out.println("Unfortunately, you have entered wrong time format...\nPlease enter again in format HH:MM");
           }
        }

        isTimeCorrect = false;

        while (!isAdded){
            try {
                BLManegment.addNewTripRequest(name, from, to, hour, minute, isExitBoolean);
                isAdded = true;
            } catch (NoNameEnteredException e) {
                System.out.println("No name was entered, Can you enter your name please ?");
                name = myScanner.nextLine();
            } catch (WrongMinutesException e) {

                System.out.println("The minutes (" + e.getMessage() +") must be with 0 or 5 digit at the end and between 0-59\nPlease enter the time again");

                while (!isTimeCorrect){
                    time = myScanner.nextLine();
                    try {
                        hour = Integer.parseInt(time.split(":")[0]);
                        minute = Integer.parseInt(time.split(":")[1]);
                        isTimeCorrect = true;
                    } catch (Exception ex) {
                        System.out.println("Unfortunately, you have entered wrong time format...\nPlease enter again in format HH:MM");
                    }
                }

            } catch (StopDoesntExistException e) {
                if (e.getMessage().equals("original")){
                    System.out.println("Original station " + from + " does not exist in the system\nPlease enter stop from the following list:");
                    for(String stop : BLManegment.getAllStopsNames()) {
                        System.out.println(stop + ",");
                    }
                    from = myScanner.nextLine();
                } else if (e.getMessage().equals("destination")) {
                    System.out.println("Destination station " + to + " does not exist in the system\nPlease enter stop from the following list:");
                    for(String stop : BLManegment.getAllStopsNames()) {
                        System.out.println(stop + ",");
                    }
                    to = myScanner.nextLine();
                }

            } catch (WrongHourException e) {
                System.out.println("Hour " + e.getMessage() +" must be between 0-23\nPlease enter the time again");
                while (!isTimeCorrect){
                    time = myScanner.nextLine();
                    try {
                        hour = Integer.parseInt(time.split(":")[0]);
                        minute = Integer.parseInt(time.split(":")[1]);
                        isTimeCorrect = true;
                    } catch (Exception ex) {
                        System.out.println("Unfortunately, you have entered wrong time format...\nPlease enter again in format HH:MM");
                    }
                }
            }
        }
        System.out.println("Request was added successfully !");
    }

    public static void showAllOffers() {

        List<String> tripOffersDescriptions = BLManegment.getAllTripOffers();

        if (tripOffersDescriptions.size() == 0){
            System.out.println("There are no trip offers in the system...\n");
        } else {
            System.out.println("These are all the offers that we have in the system:\n");
            for(String offer : tripOffersDescriptions) {
                System.out.println(offer + "\n");
            }
        }
    }

    public static void showAllRequests(){

        List<String> tripRequestsDescriptions = BLManegment.getAllTripRequests();

        if (tripRequestsDescriptions.size() == 0){
            System.out.println("There are no trip requests in the system at the moment...\n");
        } else {
            System.out.println("These are all the trip requests in the system:\n");
            for (String request: tripRequestsDescriptions) {
                System.out.println(request + "\n");
            }
        }
    }

    public static void findMatchings(){
        int integerRequestId, integerOptionsMax, integerChoice;

        List<String> unmatchedRequests = BLManegment.getAllUnmatchedRequests();

        if (unmatchedRequests.size() == 0){
            System.out.println("There are no trip requests in the system at the moment...");
        } else {
            System.out.println("These are all the unmatched trip requests in the system:\n");
            for (String request: unmatchedRequests) {
                System.out.println(request + "\n");
            }

            integerRequestId = getInteger("Please choose trip request to match (By it's id):");

            integerOptionsMax = getInteger("Please enter how many match options do you want to see at most?");

            List<String> matches = BLManegment.findMatches(integerRequestId, integerOptionsMax);

            if (matches.size() == 0){
                System.out.println("There are no trip matches in the system at the moment...");
                return;
            } else {
                System.out.println("These are all the trip matches in the system:\n");
                for (String match: matches) {
                    System.out.println(match + "\n");
                }
            }

            integerChoice = getInteger("Enter your preferred match by it's id,\nIf you want to cancel -1");

            if(integerChoice != -1) {
                try {
                    BLManegment.match(integerRequestId, integerChoice);
                    System.out.println("Successful match!");
                } catch (MatchDoesntExistException e) {
                    System.out.println("Unfortunately, match number " + integerChoice + " does not exist\n");
                }
            }
        }
    }

    public static void createNewTripOffer() {

        String name,path, selectedRecurrences = null;
        int hour,userChoice = -1, ppk,capacity;
        boolean isChoiceCorrect = false;

        System.out.println("What is your name?:");
        name = myScanner.nextLine();

        System.out.println("Please enter your path with commas (,) between the stops names");
        path = myScanner.nextLine();

        // TODO day of leaving - according to system count

        hour = getInteger("On which hour do you want to Exit? (0-23)");

        System.out.println("Choose one of the following recurrences:\n" +
                           "1 - " + Constants.RECURRENCE_ONE_TIME + "\n" +
                           "2 - " + Constants.RECURRENCE_DAILY + "\n" +
                           "3 - " + Constants.RECURRENCE_DOUBLE_DAILY + "\n" +
                           "4 - " + Constants.RECURRENCE_WEEKLY + "\n" +
                           "5 - " + Constants.RECURRENCE_MONTHLY );

        while (!isChoiceCorrect) {
            try {
                userChoice = Integer.parseInt(myScanner.nextLine());

                if (userChoice != 1 && userChoice != 2 &&
                        userChoice != 3 && userChoice != 4 && userChoice != 5) {
                    System.out.println("Unfortunately, you have entered a wrong input...\n" +
                            "Choose one of the following recurrences:\n" +
                            "1 - " + Constants.RECURRENCE_ONE_TIME + "\n" +
                            "2 - " + Constants.RECURRENCE_DAILY + "\n" +
                            "3 - " + Constants.RECURRENCE_DOUBLE_DAILY + "\n" +
                            "4 - " + Constants.RECURRENCE_WEEKLY + "\n" +
                            "5 - " + Constants.RECURRENCE_MONTHLY);
                } else {
                    isChoiceCorrect = true;
                }

            } catch (Exception e) {
                System.out.println("Unfortunately, you have entered a wrong input...\n" +
                                   "Choose one of the following recurrences:\n" +
                                   "1 - " + Constants.RECURRENCE_ONE_TIME + "\n" +
                                   "2 - " + Constants.RECURRENCE_DAILY + "\n" +
                                   "3 - " + Constants.RECURRENCE_DOUBLE_DAILY + "\n" +
                                   "4 - " + Constants.RECURRENCE_WEEKLY + "\n" +
                                   "5 - " + Constants.RECURRENCE_MONTHLY);
            }
        }

        switch (userChoice){
            case 1:
                selectedRecurrences = Constants.RECURRENCE_ONE_TIME;
                break;
            case 2:
                selectedRecurrences = Constants.RECURRENCE_DAILY;
                break;
            case 3:
                selectedRecurrences = Constants.RECURRENCE_DOUBLE_DAILY;
                break;
            case 4:
                selectedRecurrences = Constants.RECURRENCE_WEEKLY;
                break;
            case 5:
                selectedRecurrences = Constants.RECURRENCE_MONTHLY;
                break;
        }

        ppk = getInteger("Please enter your price per kilometer");

        capacity = getInteger("Please enter your capacity (NOT including you)");

        try {
            BLManegment.addNewTripOffer(name, path, hour, selectedRecurrences, ppk,  capacity);
            System.out.println("The trip offer was added successfully !");
        } catch (NegativeNumberException e) {
            if (e.getMessage().isEmpty()){
                System.out.println("What is the meaning of the negative number?");
            } else {
                System.out.println(e.getMessage());
            }
        } catch (WrongRecurrencesException e) {
            System.out.println("We have an unexpected recurrence entered");
            System.out.println("Recurrence " + e.getMessage() + " does not exist in the system");
        } catch (WrongHourException e) {
            System.out.println("We have an unexpected hour entered");
        } catch (WrongRouteException e) {
            System.out.println("There is no route like " + path);
        }
    }
}

