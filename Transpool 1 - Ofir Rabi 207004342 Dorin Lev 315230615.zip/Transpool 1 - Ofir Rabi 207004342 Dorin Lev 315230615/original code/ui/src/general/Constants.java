package general;

public class Constants {
    public static final int CHOICE_REQUEST_TRIP = 1;
    public static final int CHOICE_SHOW_ALL_OFFERS  = 2;
    public static final int CHOICE_SHOW_ALL_REQUESTS  = 3;
    public static final int CHOICE_MATCH = 4;
    public static final int CHOICE_NEW_TRIP_OFFER = 5;
    public static final int CHOICE_EXIT = 6;
    public static final int CHOICE_RESTART = 7;

    public static final String RECURRENCE_ONE_TIME = "OneTime";
    public static final String RECURRENCE_DAILY = "Daily";
    public static final String RECURRENCE_DOUBLE_DAILY = "BiDaily";
    public static final String RECURRENCE_WEEKLY = "Weekly";
    public static final String RECURRENCE_MONTHLY = "Monthly";
}
