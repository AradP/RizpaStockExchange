package models;

public class Path {

    private String from;
    private String to;
    private boolean oneWay;
    private int length;
    private int fuelConsumption;
    private int speedLimit;
//  Calculated members
    private int timeInMinutes;

    public Path(String from, String to, boolean oneWay, int length, int fuelConsumption, int speedLimit) {
        this.from = from;
        this.to = to;
        this.oneWay = oneWay;
        this.length = length;
        this.fuelConsumption = fuelConsumption;
        this.speedLimit = speedLimit;
    }

    public int getTimeInMinutes() {
        return timeInMinutes;
    }

    public void setTimeInMinutes(int timeInMinutes) {
        this.timeInMinutes = timeInMinutes;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public boolean isOneWay() {
        return oneWay;
    }

    public int getLength() {
        return length;
    }

    public int getFuelConsumption() {
        return fuelConsumption;
    }

    public int getSpeedLimit() {
        return speedLimit;
    }
}
