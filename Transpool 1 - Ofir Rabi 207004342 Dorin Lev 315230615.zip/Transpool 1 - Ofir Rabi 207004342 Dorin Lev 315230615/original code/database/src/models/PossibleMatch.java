package models;

import db.Paths;
import db.TripOffers;
import db.TripRequests;

public class PossibleMatch {
    private TripRequest request;
    private TripOffer offer;
    private int cost;
    private String finishTime;
    private int fuelConsumption;

    public PossibleMatch(int requestId, int offerId) {
        request = TripRequests.getRequest(requestId);
        offer = TripOffers.getOffer(offerId);

        this.cost = calculateCost();
        this.finishTime = calculateFinishTime();
        this.fuelConsumption = calculateFuelConsumption();
    }

    public TripRequest getRequest() {
        return request;
    }

    public TripOffer getOffer() {
        return offer;
    }

    public int getCost() {
        return cost;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public int getFuelConsumption() {
        return fuelConsumption;
    }

    //  When the driver arrive to destination
    private String calculateFinishTime() {
//        int minutes = offer.getRoute().getTravelingTimeUntilStop(request.getDestinationStop().getName());
//        int arriveHour = offer.getScheduling().getHourStart() + minutes / 60;
//        return arriveHour + ":" + minutes % 60;
        return null;
    }

    private int calculateCost() {
        int kilometers = 0;

        for(int i = offer.getRoute().getStops().indexOf(request.getOriginStop().getName());
            i < offer.getRoute().getStops().indexOf(request.getDestinationStop().getName());
            i++) {
            kilometers += Paths.getPath(offer.getRoute().getStops().get(i), offer.getRoute().getStops().get(i + 1)).getLength();
        }

        return kilometers * offer.getPpk();
    }

    private int calculateFuelConsumption() {
        int fuel = 0, divider = 0;

        for(int i = offer.getRoute().getStops().indexOf(request.getOriginStop().getName());
            i < offer.getRoute().getStops().indexOf(request.getDestinationStop().getName());
            i++) {
            divider++;
            fuel += Paths.getPath(offer.getRoute().getStops().get(i), offer.getRoute().getStops().get(i + 1)).getFuelConsumption();
        }

        return fuel / divider;
    }
}
