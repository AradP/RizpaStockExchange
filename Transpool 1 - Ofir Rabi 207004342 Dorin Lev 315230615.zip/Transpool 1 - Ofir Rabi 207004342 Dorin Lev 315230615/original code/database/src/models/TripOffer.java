package models;

public class TripOffer {

    private static int idCounter = 1;
    private int id;
    private String owner;
    private int capacity;
    private int ppk;
    private Route route;
    private Scheduling scheduling;
//  Calculated members
    private int tripValue; // Route length * PPK
    private int tripTimeInMinutes; // All paths time in minutes
    private int averageFuelConsumption;

    public TripOffer(String owner, int capacity, int ppk, Route route, Scheduling scheduling) {
        this.owner = owner;
        this.capacity = capacity;
        this.ppk = ppk;
        this.route = route;
        this.scheduling = scheduling;
        this.id = TripOffer.idCounter++;
    }

    public int getAverageFuelConsumption() {
        return averageFuelConsumption;
    }

    public void setAverageFuelConsumption(int averageFuelConsumption) {
        this.averageFuelConsumption = averageFuelConsumption;
    }

    public int getTripTimeInMinutes() {
        return tripTimeInMinutes;
    }

    public void setTripTimeInMinutes(int tripTimeInMinutes) {
        this.tripTimeInMinutes = tripTimeInMinutes;
    }

    public int getTripValue() {
        return tripValue;
    }

    public void setTripValue(int tripValue) {
        this.tripValue = tripValue;
    }

    public int getId() {
        return id;
    }

    public String getOwner() {
        return owner;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getPpk() {
        return ppk;
    }

    public Route getRoute() { return route; }

    public Scheduling getScheduling() { return scheduling; }
}
