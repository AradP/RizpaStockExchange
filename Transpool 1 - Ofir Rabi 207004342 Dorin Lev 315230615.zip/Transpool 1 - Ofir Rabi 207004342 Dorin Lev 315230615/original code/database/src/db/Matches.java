package db;

import models.Match;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Matches {
    private static List<Match> matches = new ArrayList<>();

    public static List<Match> getMatches() {
        return Matches.matches;
    }

    public static void addMatch(Match match) {
        Matches.matches.add(match);
    }

    public static List<Match> getAllByRequestId(int id) {
        return matches.stream().filter(match -> (match.getRequestId() == id)).collect(Collectors.toList());
    }

    public static List<Match> getAllByOfferId(int id) {
        return matches.stream().filter(match -> (match.getOfferId() == id)).collect(Collectors.toList());
    }

    public static void clearMatches() {
        Matches.matches = new ArrayList<>();
    }
}
