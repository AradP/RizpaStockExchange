package db;

import models.TripRequest;
import java.util.ArrayList;
import java.util.List;

public class TripRequests {
    private static List<TripRequest> tripRequests = new ArrayList<>();

    public static List<TripRequest> getTripRequests() {
        return TripRequests.tripRequests;
    }

    public static void setTripRequests(List<TripRequest> tripRequests) {
        TripRequests.tripRequests = tripRequests;
    }

    public static void addTripRequest(TripRequest tripRequest) {
        TripRequests.tripRequests.add(tripRequest);
    }

    public static TripRequest getRequest(int id) {
        for (TripRequest currentRequest: TripRequests.getTripRequests() ) {
            if(currentRequest.getId() == id){
                return currentRequest;
            }
        }

        return null;
    }

    public static void clearRequests() {
        TripRequests.tripRequests = new ArrayList<>();
    }
}
