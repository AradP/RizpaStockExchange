package db;

import models.MapBoundries;

public class MapBoundriesDB {
    private static MapBoundries mapBoundries;

    public static MapBoundries getMapBoundries() {
        return MapBoundriesDB.mapBoundries;
    }

    public static void setMapBoundries(MapBoundries mapBoundries) {
        MapBoundriesDB.mapBoundries = mapBoundries;
    }

    public static void clearMapBoundries() {
        MapBoundriesDB.mapBoundries = null;
    }
}
