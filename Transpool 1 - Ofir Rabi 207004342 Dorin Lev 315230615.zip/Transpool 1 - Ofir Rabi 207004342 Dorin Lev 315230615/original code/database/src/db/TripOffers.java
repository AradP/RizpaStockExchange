package db;

import models.TripOffer;
import java.util.ArrayList;
import java.util.List;

public class TripOffers {
    private static List<TripOffer> tripOffers = new ArrayList<>();

    public static List<TripOffer> getTripOffers() {
        return TripOffers.tripOffers;
    }

    public static void setTripOffers(List<TripOffer> tripOffers) {
        TripOffers.tripOffers = tripOffers;
    }

    public static TripOffer getOffer(int id) {
        for (TripOffer currentOffer: TripOffers.getTripOffers() ) {
            if(currentOffer.getId() == id){
                return currentOffer;
            }
        }

        return null;
    }

    public static void addNewOffer(TripOffer tripOffer){
        tripOffers.add(tripOffer);
    }

    public static void addTripOffers(List<TripOffer> newTripOffers) { tripOffers.addAll(newTripOffers); }

    public static void clearOffers() {
        TripOffers.tripOffers = new ArrayList<>();
    }
}
