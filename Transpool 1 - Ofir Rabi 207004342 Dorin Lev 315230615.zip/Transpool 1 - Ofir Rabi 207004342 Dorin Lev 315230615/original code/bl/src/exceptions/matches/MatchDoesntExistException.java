package exceptions.matches;

public class MatchDoesntExistException extends Exception {
    public MatchDoesntExistException() {
        super();
    }
}
