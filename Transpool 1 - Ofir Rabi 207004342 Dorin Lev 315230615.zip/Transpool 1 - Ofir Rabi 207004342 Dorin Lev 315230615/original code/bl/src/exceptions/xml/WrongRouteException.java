package exceptions.xml;

public class WrongRouteException extends Exception {
    public WrongRouteException() {
        super();
    }
    public WrongRouteException(String message) {
        super(message);
    }
}
