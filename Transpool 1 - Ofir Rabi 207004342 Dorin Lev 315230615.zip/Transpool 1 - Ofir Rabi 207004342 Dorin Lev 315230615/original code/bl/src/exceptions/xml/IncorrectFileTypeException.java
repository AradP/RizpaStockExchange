package exceptions.xml;

public class IncorrectFileTypeException extends Exception{
    public IncorrectFileTypeException() {
        super();
    }
}
