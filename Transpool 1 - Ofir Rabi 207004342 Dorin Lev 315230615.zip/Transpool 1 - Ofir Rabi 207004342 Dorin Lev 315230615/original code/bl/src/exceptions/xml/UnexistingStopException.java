package exceptions.xml;

public class UnexistingStopException extends Exception {
    public UnexistingStopException() {
        super();
    }

    public UnexistingStopException(String message) {
        super(message);
    }
}
