package exceptions.xml;

public class WrongMapBoundriesException extends Exception {
    public WrongMapBoundriesException() {
        super();
    }
}
