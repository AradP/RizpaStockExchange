package exceptions.xml;

public class NotInMapBoundriesException extends Exception {
    public NotInMapBoundriesException() {
        super();
    }

    public NotInMapBoundriesException(String message) {
        super(message);
    }
}
