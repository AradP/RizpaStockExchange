package exceptions.xml;

public class NotUniqueLocationException extends Exception {
    public NotUniqueLocationException() {
        super();
    }
    public NotUniqueLocationException(String message) {
        super(message);
    }
}
