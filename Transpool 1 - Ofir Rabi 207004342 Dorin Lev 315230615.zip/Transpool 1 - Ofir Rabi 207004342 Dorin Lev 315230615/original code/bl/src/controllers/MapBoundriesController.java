package controllers;

import db.MapBoundriesDB;
import models.MapBoundries;

public class MapBoundriesController {
    public static boolean inMapBoundries(int x, int y){
        return ((x >= 0 && x <= MapBoundriesDB.getMapBoundries().getWidth()) && (y >= 0 && y <= MapBoundriesDB.getMapBoundries().getHeight()));
    }
    public static void setMapBoundries(MapBoundries mapBoundries) {
        MapBoundriesDB.setMapBoundries(mapBoundries);
    }
}
