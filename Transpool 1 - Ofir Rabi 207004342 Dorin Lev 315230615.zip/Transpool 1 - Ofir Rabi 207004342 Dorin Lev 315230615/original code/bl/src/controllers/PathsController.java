package controllers;

import db.Paths;
import models.Path;
import java.util.List;

public class PathsController {
    public static void addPaths(List<Path> newPaths) {

//      Fill all calculated parameters for path
        for (Path newPath : newPaths) {
            newPath.setTimeInMinutes(
                    (int)(((double)newPath.getLength() / (double)newPath.getSpeedLimit()) * 60)
            );
        }

        Paths.addPaths(newPaths);
    }
}
