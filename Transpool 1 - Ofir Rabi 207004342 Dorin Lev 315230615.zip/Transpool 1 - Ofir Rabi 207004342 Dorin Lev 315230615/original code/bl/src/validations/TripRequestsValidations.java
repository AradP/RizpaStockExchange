package validations;

import controllers.StopsController;
import exceptions.general.*;
import exceptions.tripRequests.*;

public class TripRequestsValidations {

    public static void checkNewTripRequest(String name, String originStopName, String destinationStopName, int tripHour, int tripMinute) throws NoNameEnteredException, StopDoesntExistException, WrongHourException, WrongMinutesException {

        if (!validations.TripRequestsValidations.hasName(name)){
            throw new NoNameEnteredException();
        } else if (StopsController.getStopByName(originStopName) == null){
            throw new StopDoesntExistException("original");
        } else if (StopsController.getStopByName(destinationStopName) == null) {
            throw new StopDoesntExistException("destination");
        } else if (!isHourCorrect(tripHour)) {
            throw new WrongHourException(String.valueOf(tripHour));
        } else if (!isMinutesDividedBy5(tripMinute)){
            throw new WrongMinutesException(String.valueOf(tripMinute));
        }
    }

    private static boolean hasName(String name){
        return !name.isEmpty();
    }

    private static boolean isHourCorrect(int hour){
        return (hour >= 0 && hour < 24);
    }

    private static boolean isMinutesDividedBy5 (int minutes){
        return (minutes % 5 == 0 && minutes >= 0 && minutes < 60);
    }
}
